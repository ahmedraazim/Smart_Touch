<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Purchase Order</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.14/jspdf.plugin.autotable.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<?php
$itemName = isset($_GET['item_name']) ? htmlspecialchars($_GET['item_name']) : '';
$supplier = isset($_GET['supplier']) ? htmlspecialchars($_GET['supplier']) : '';

// Start output buffering to prevent header errors
ob_start();
include 'header.php'; // Include the header

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the order number from the request
$orderNumber = $_GET['order_number'] ?? ''; // Make sure to sanitize this input in production

if (!empty($orderNumber)) {
    // Fetch order details
    $orderQuery = $conn->query("SELECT * FROM purchase_orders WHERE order_number = '$orderNumber'");
    $orderDetails = $orderQuery->fetch_assoc();

    // Fetch received items details from the stock table
    $receivedQuery = $conn->query("SELECT * FROM stock WHERE order_number = '$orderNumber'");
    
    // Fetch returned items details from the supplier_return table
    $returnQuery = $conn->query("SELECT * FROM supplier_return WHERE order_number = '$orderNumber'");

    // Start HTML output for the invoice
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Invoice - ' . $orderNumber . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1, h2 { color: #00408e; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #479057; color: white; }
            .total { font-weight: bold; }
        </style>
    </head>
    <body>
        <h1>Invoice</h1>
        <h2>Order Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Order Number</th>
                    <th>Supplier</th>
                    <th>Delivery Date</th>
                    <th>Original Quantity</th>
                    <th>Received Quantity</th>
                    <th>Returned Quantity</th>
                    <th>Warranty</th>
                    <th>Item Name</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>';
    
    // Display order details
    if ($orderQuery->num_rows > 0) {
        $totalAmount = 0; // For calculating total amount
        do {
            echo '<tr>
                    <td>' . $orderDetails['order_number'] . '</td>
                    <td>' . $orderDetails['supplier'] . '</td>
                    <td>' . $orderDetails['delivery_date'] . '</td>
                    <td>' . $orderDetails['quantity'] . '</td>
                    <td>' . $orderDetails['received_quantity'] . '</td>
                    <td>' . $orderDetails['returned_quantity'] . '</td>
                    <td>' . $orderDetails['warranty'] . '</td>
                    <td>' . $orderDetails['item_name'] . '</td>
                    <td>' . number_format($orderDetails['price_per_unit'], 2) . '</td>
                    <td>' . number_format($orderDetails['total'], 2) . '</td>
                </tr>';
            $totalAmount += $orderDetails['total'];
        } while ($orderDetails = $orderQuery->fetch_assoc());
        echo '<tr class="total">
                <td colspan="9" style="text-align: right;">Grand Total:</td>
                <td>' . number_format($totalAmount, 2) . '</td>
            </tr>';
    }
    
    echo '</tbody>
        </table>';
    
    // Received and Returned Items Section
    echo '<h2>Received and Returned Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Received Serial Numbers</th>
                    <th>Received Models</th>
                    <th>Returned Serial Numbers</th>
                    <th>Returned Models</th>
                </tr>
            </thead>
            <tbody>';
    
    // Display received and returned details
    if ($receivedQuery->num_rows > 0 || $returnQuery->num_rows > 0) {
        // Fetch received details
        while ($receivedItem = $receivedQuery->fetch_assoc()) {
            echo '<tr>
                    <td>' . $receivedItem['order_number'] . '</td>
                    <td>' . $receivedItem['serial_number'] . '</td>
                    <td>' . $receivedItem['model'] . '</td>
                    <td>-</td>
                    <td>-</td>
                </tr>';
        }

        // Fetch returned details
        while ($returnItem = $returnQuery->fetch_assoc()) {
            echo '<tr>
                    <td>' . $returnItem['order_number'] . '</td>
                    <td>-</td>
                    <td>-</td>
                    <td>' . $returnItem['serial_number'] . '</td>
                    <td>' . $returnItem['model'] . '</td>
                </tr>';
        }
    } else {
        echo '<tr><td colspan="5" class="text-center text-muted">No items have been received or returned for this order yet.</td></tr>';
    }
    
    echo '</tbody>
        </table>
    </body>
    </html>';
} else {
    echo "";
}

// Function to auto-increment order number
function getNextOrderNumber($conn) {
    $result = $conn->query("SELECT MAX(order_number) AS max_order FROM purchase_orders");
    $row = $result->fetch_assoc();
    $currentOrderNumber = $row['max_order'];
    
    if ($currentOrderNumber) {
        $numericPart = (int) substr($currentOrderNumber, 3);
        return 'PO-' . str_pad($numericPart + 1, 5, '0', STR_PAD_LEFT);
    } else {
        return 'PO-00001';
    }
}

// Create a purchase order and insert into the purchase_orders table
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_order'])) {
    $orderNumber = getNextOrderNumber($conn);
    $supplier = $_POST['supplier'];
    $deliveryDate = $_POST['delivery_date'];
    $itemsJson = $_POST['items'];

    if (!empty($supplier) && !empty($deliveryDate) && !empty($itemsJson)) {
        $items = json_decode($itemsJson, true);
        
        if (is_array($items) && !empty($items)) {
            foreach ($items as $item) {
                $itemName = $item['name'];
                $quantity = $item['quantity'];
                $pricePerUnit = $item['price_per_unit'];
                $total = $quantity * $pricePerUnit; // Update total calculation
                $warranty = $item['warranty'];

                // Insert the item into the purchase_orders table
                $sql = "INSERT INTO purchase_orders (order_number, supplier, delivery_date, item_name, quantity, price_per_unit, total, warranty)
                VALUES ('$orderNumber', '$supplier', '$deliveryDate', '$itemName', '$quantity', '$pricePerUnit', '$total', '$warranty')";
                      
                if (!$conn->query($sql)) {
                    echo "<script>alert('Error: " . $conn->error . "');</script>";
                }
            }
            echo '<div id="success-alert" class="alert alert-success" role="alert">Purchase Order created successfully!</div>';
        }
    } else {
        echo '<div id="error-message" style="
        color: white; 
        background-color: red; 
        padding: 15px; 
        border-radius: 5px; 
        margin: 20px auto; 
        text-align: center; 
        width: 50%; 
        font-weight: bold;">
        Error: Please fill in all required fields.
    </div>
    <script>
        // JavaScript to make the error message disappear after 5 seconds
        setTimeout(function() {
            var errorMessage = document.getElementById("error-message");
            if (errorMessage) {
                errorMessage.style.display = "none"; // Hide the message
            }
        }, 5000); // 5000 milliseconds = 5 seconds
    </script>';
        }
}

// Handle receiving items
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['receive_item'])) {
    $orderNumber = $_POST['order_number'];
    $itemName = $_POST['item_name'];
    $supplier = $_POST['supplier'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $serialNumbers = isset($_POST['serial_numbers']) && is_array($_POST['serial_numbers']) ? implode(',', $_POST['serial_numbers']) : '';
    $models = isset($_POST['models']) && is_array($_POST['models']) ? implode(',', $_POST['models']) : '';
    $warranty = isset($_POST['warranty']) ? $_POST['warranty'] : ''; // Capture warranty from form
    $receivedDate = date("Y-m-d");

    // Fetch original quantity from the database
    $fetchQuery = $conn->query("SELECT quantity, received_quantity, returned_quantity FROM purchase_orders WHERE order_number='$orderNumber' AND item_name='$itemName'");
    $orderData = $fetchQuery->fetch_assoc();
    
    $originalQuantity = $orderData['quantity'];
    $receivedQuantity = $orderData['received_quantity'];
    $returnedQuantity = $orderData['returned_quantity'];

    // Validate the quantity (Total Received + Returned should not exceed the Original Quantity)
    if (($receivedQuantity + $returnedQuantity + $quantity) > $originalQuantity) {
        echo "<script>alert('Error: Total of received and returned items cannot exceed the total quantity ordered.');</script>";
    } else {
        // Proceed with receiving items
        $updateSerialQuery = "UPDATE purchase_orders 
                              SET received_serial_numbers = CONCAT(COALESCE(received_serial_numbers, ''), ',', '$serialNumbers'),
                                  received_models = CONCAT(COALESCE(received_models, ''), ',', '$models'),
                                  received_quantity = received_quantity + $quantity 
                              WHERE order_number='$orderNumber' AND item_name='$itemName'";
        
        if (!$conn->query($updateSerialQuery)) {
            echo "<script>alert('Error updating received items: " . $conn->error . "');</script>";
        }

        // Insert into stock table (for tracking individual items)
        $stockQuery = "INSERT INTO stock (order_number, item_name, quantity, received_date, supplier, serial_number, model, warranty)
                       VALUES ('$orderNumber', '$itemName', $quantity, '$receivedDate', '$supplier', '$serialNumbers', '$models', '$warranty')";
        if (!$conn->query($stockQuery)) {
            echo "<script>alert('Error inserting into stock: " . $conn->error . "');</script>";
        }

        echo "<script>alert('Items received successfully!');</script>";
    }
}

// Handle returning items
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['return_item'])) {
    $orderNumber = $_POST['order_number'];
    $itemName = $_POST['item_name'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $serialNumbers = isset($_POST['serial_numbers']) && is_array($_POST['serial_numbers']) ? implode(',', $_POST['serial_numbers']) : '';
    $models = isset($_POST['models']) && is_array($_POST['models']) ? implode(',', $_POST['models']) : '';
    $warranty = isset($_POST['warranty']) ? $_POST['warranty'] : ''; // Ensure warranty is defined
    $returnDate = date("Y-m-d");
    // Fetch original quantities to validate
    $fetchQuery = $conn->query("SELECT quantity, received_quantity, returned_quantity FROM purchase_orders 
    WHERE order_number='$orderNumber' AND item_name='$itemName'");
    $orderData = $fetchQuery->fetch_assoc();
    if ($orderData) {
        $originalQuantity = $orderData['quantity'];
        $receivedQuantity = $orderData['received_quantity'];
        $returnedQuantity = $orderData['returned_quantity'];
        if (($receivedQuantity + $returnedQuantity + $quantity) > $originalQuantity) {
            echo "<script>alert('Error: Total of received and returned items cannot exceed the total quantity ordered.');</script>";
        } else {
            $updateReturnQuantityQuery = "UPDATE purchase_orders 
                                          SET returned_quantity = returned_quantity + $quantity, 
                                              returned_serial_numbers = CONCAT(COALESCE(returned_serial_numbers, ''), ',', '$serialNumbers'), 
                                              returned_models = CONCAT(COALESCE(returned_models, ''), ',', '$models') 
                                          WHERE order_number='$orderNumber' AND item_name='$itemName'";
            if ($conn->query($updateReturnQuantityQuery) === TRUE) {
                $returnQuery = "INSERT INTO supplier_return (order_number, item_name, quantity, return_date, supplier, serial_number, 
                model, warranty)
                                VALUES ('$orderNumber', '$itemName', $quantity, '$returnDate', 
                                (SELECT supplier FROM purchase_orders WHERE order_number='$orderNumber' AND item_name='$itemName'),
                                '$serialNumbers', '$models', '$warranty')";
                if ($conn->query($returnQuery) === TRUE) {
                    echo "<script>alert('Items returned successfully!');</script>";
                } else {         echo "<script>alert('Error inserting into supplier_return: " . $conn->error . "');</script>";
                }
            } else {     echo "<script>alert('Error updating returned quantity in purchase_orders: " . $conn->error . "');</script>";
            }    }
    } else {     echo "<script>alert('Error: Order not found.');</script>";
    }
}

// Pagination logic for orders
$limit = 10; // Number of orders per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit; // Calculate the starting row for the query

// Fetch total number of orders
$totalOrdersResult = $conn->query("SELECT COUNT(*) as total FROM purchase_orders");
$totalOrders = $totalOrdersResult->fetch_assoc()['total'];
$totalPages = ceil($totalOrders / $limit);

// Fetch orders with pagination
$orders = [];
$orderQuery = $conn->query("SELECT * FROM purchase_orders ORDER BY id DESC LIMIT $limit OFFSET $offset");

if ($orderQuery->num_rows > 0) {
    while ($row = $orderQuery->fetch_assoc()) {
        $orders[] = $row;
    }
}

// Fetch product names for dropdown
$productNames = [];
$productQuery = $conn->query("SELECT product_name FROM products");
if ($productQuery->num_rows > 0) {
    while ($product = $productQuery->fetch_assoc()) {
        $productNames[] = $product['product_name'];
    }
}

$supplierNames = [];
$supplierQuery = $conn->query("SELECT name FROM suppliers WHERE status = 'Active'");
if ($supplierQuery->num_rows > 0) {
    while ($supplier = $supplierQuery->fetch_assoc()) {
        $supplierNames[] = $supplier['name'];  // Store only the name
    }
}
?>

<div class="container">
    <!-- Back to Home Button -->
    <div class="mb-3">
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
    </div>
    <h1>Create Purchase Order</h1>

    <div id="alert-container"></div> <!-- Alert container for warning/alert messages -->
   
    <form method="POST" id="purchase-order-form">
        <div class="form-group">
            <label for="order-number">Order Number</label>
            <input type="text" id="order-number" name="order_number" value="<?= getNextOrderNumber($conn); ?>" readonly>
        </div>

        <div class="form-group">
            <label for="purchase-date">Purchase Date</label>
            <input type="date" id="purchase-date" value="" readonly>
        </div>

        <div class="form-group">
            <label for="delivery-date">Delivery Date</label>
            <input type="date" id="delivery-date" name="delivery_date" value="">
        </div>

        <div class="form-group">
            <label for="currency">Currency</label>
            <select id="currency" onchange="updateTotal()">
                <option value="USD">USD - United States Dollar</option>
            </select>
        </div>

        <div class="form-group">
            <label for="supplier">Supplier</label>
            <select id="supplier" name="supplier">
                <option value="" disabled selected>Select Supplier</option>
                <?php foreach ($supplierNames as $supplierName): ?>
                    <option value="<?= htmlspecialchars($supplierName) ?>"><?= htmlspecialchars($supplierName) ?></option>
                <?php endforeach; ?>
            </select>

        </div>

        <h2>Items</h2>

        <table class="item-table" id="item-table">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price per Unit</th>
                    <th>Warranty</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="item-list">
                <tr>
                    <td>
                        <select name="item_name" id="item-name" required>
                            <option value="" disabled selected>Select Product</option>
                            <?php foreach ($productNames as $productName): ?>
                                <option value="<?= htmlspecialchars($productName) ?>"><?= htmlspecialchars($productName) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><input type="number" name="quantity" placeholder="Quantity" required oninput="updateTotalInRow(this)"></td>
                    <td><input type="number" name="price_per_unit" placeholder="Price per Unit" required oninput="updateTotalInRow(this)"></td>
                    <td><input type="text" name="warranty" placeholder="Warranty"></td>
                    <td class="total">0.00</td>
                    <td><button type="button" onclick="removeItem(this)" style="background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer;">Remove</button></td>
                    </tr>
            </tbody>
        </table>

        <button type="button" class="add-item-btn" onclick="addItem()">Add Item</button>

        <div class="total-container" id="total-container">
            Subtotal: $<span id="subtotal-amount"></span> <span id="currency-symbol">USD</span><br>
            Total: $<span id="total-amount">0.00</span>
        </div>

        <input type="hidden" id="items-json" name="items">

        <div class="buttons-container">
            <button type="submit" class="create-order-btn" name="create_order">Create Purchase Order</button>
        </div>
    </form>

    <h2>Existing Orders</h2>
    <div class="table-container">
        <input type="text" id="search-input" placeholder="Search for orders by number...">
        <button id="search-btn" onclick="searchOrders()">Search</button>

        <table class="actions-table" id="order-list">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Order ID</th>
                    <th>Supplier</th>
                    <th>Delivery Date</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price per Unit</th>
                    <th>Warranty</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
<?php foreach ($orders as $order): ?>
    <?php
        // Check if the order is complete and payment status
        $isComplete = ($order['received_quantity'] + $order['returned_quantity']) == $order['quantity'];
        $statusColor = $isComplete ? 'green' : 'black';
        $statusText = "Received: {$order['received_quantity']}, Returned: {$order['returned_quantity']}";
        $showPayNowButton = $order['payment_status'] === 'Unpaid'; // Only show button if unpaid
    ?>
    <tr>
        <td><input type="checkbox" class="item-checkbox" onclick="toggleCheckboxes(this)"></td>
        <td><?= $order['order_number']; ?></td>
        <td><?= $order['supplier']; ?></td>
        <td><?= $order['delivery_date']; ?></td>
        <td><?= $order['item_name']; ?></td>
        <td><?= $order['quantity']; ?></td>
        <td><?= $order['price_per_unit']; ?></td>
        <td><?= $order['warranty']; ?></td>
        <td><?= $order['total']; ?></td>
        <td class="status" style="color: <?= $statusColor; ?>;">
            <?= $statusText; ?>
            <?php if ($isComplete && $showPayNowButton): ?>
                <button class="pay-now-btn" onclick="window.location.href='Pay_suppliers.php?order_number=<?= $order['order_number']; ?>'">Pay Now</button>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>
</tbody>

        </table>
    </div>

    <nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        <!-- Previous Button -->
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?= $page - 1 ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </span>
            </li>
        <?php endif; ?>

        <!-- Page Numbers -->
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>

        <!-- Next Button -->
        <?php if ($page < $totalPages): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?= $page + 1 ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </span>
            </li>
        <?php endif; ?>
    </ul>
</nav>

</div>

<div class="action-buttons">
    <button class="sort-btn" onclick="toggleReceiveReturnForm()">Receive/Return</button>
    <button class="print-btn" onclick="printSelectedOrders()">Print Purchase Order</button>
</div>
<br>
<!-- Receive/Return form -->
<div class="inline-receive-return-form" style="display:none;">
<form method="POST" id="receive-return-form">
    <h3>Receive/Return Item</h3>
    <div class="form-group">
        <label for="order-number">Order Number</label>
        <input type="text" id="form-order-number" name="order_number" readonly>
    </div>
    <div class="form-group">
        <label for="item-name">Item Name</label>
        <input type="text" id="form-item-name" name="item_name" readonly>
    </div>
    <div class="form-group">
        <label for="supplier">Supplier</label>
        <input type="text" id="form-supplier" name="supplier" readonly>
    </div>
    <div class="form-group">
        <label for="warranty">Warranty</label> 
        <input type="text" id="form-warranty" name="warranty" readonly>
    </div>
    <div class="form-group" id="quantity-group">
        <label for="quantity">Quantity</label>
        <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Qty" min="1" required oninput="validateQuantity(this.value)">
    </div>

    <div id="serial-model-container">
        <!-- Serial Number and Model inputs will be generated dynamically here -->
    </div>
    <div class="buttons-container">
        <button type="submit" class="create-order-btn" name="receive_item">Receive</button>
        <button type="submit" class="create-order-btn" name="return_item">Return</button>
    </div>
</form>
</div>
<br>
<footer>
</footer>

<script>
    const today = new Date();
    document.getElementById('purchase-date').valueAsDate = today;
    document.getElementById('delivery-date').valueAsDate = today;

    function prepareOrderData() {
        const itemRows = document.querySelectorAll("#item-list tr");
        const items = [];

        itemRows.forEach(row => {
            const itemName = row.querySelector('select[name="item_name"]').value;
            const quantity = parseInt(row.querySelector('input[name="quantity"]').value) || 0;
            const pricePerUnit = parseFloat(row.querySelector('input[name="price_per_unit"]').value) || 0;
            const warranty = row.querySelector('input[name="warranty"]').value.trim();
            const total = quantity * pricePerUnit;

            if (itemName && quantity > 0 && pricePerUnit > 0 && warranty) {
                items.push({
                    name: itemName,
                    quantity: quantity,
                    price_per_unit: pricePerUnit,
                    warranty: warranty,
                    total: total
                });
            }
        });

        document.getElementById('items-json').value = JSON.stringify(items);
    }

    document.getElementById("purchase-order-form").addEventListener("submit", function(event) {
        prepareOrderData();
    });

    function addItem() {
        const itemList = document.getElementById("item-list");
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>
                <select name="item_name" required>
                    <option value="" disabled selected>Select Product</option>
                    <?php foreach ($productNames as $productName): ?>
                        <option value="<?= htmlspecialchars($productName) ?>"><?= htmlspecialchars($productName) ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td><input type="number" name="quantity" placeholder="Quantity" required oninput="updateTotalInRow(this)"></td>
            <td><input type="number" name="price_per_unit" placeholder="Price per Unit" required oninput="updateTotalInRow(this)"></td>
            <td><input type="text" name="warranty" placeholder="Warranty"></td>
            <td class="total">0.00</td>
            <td><button type="button" onclick="removeItem(this)">Remove</button></td>
        `;
        itemList.appendChild(row);
    }

    function updateTotalInRow(input) {
        const row = input.closest("tr");
        const quantity = parseFloat(row.querySelector('input[name="quantity"]').value) || 0;
        const pricePerUnit = parseFloat(row.querySelector('input[name="price_per_unit"]').value) || 0;
        const totalCell = row.querySelector('.total');
        const total = (quantity * pricePerUnit).toFixed(2);
        totalCell.textContent = total;
    }

    function removeItem(button) {
        button.parentElement.parentElement.remove();
    }

    function showAlert(type, message) {
        const alertContainer = document.getElementById('alert-container');
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.textContent = message;
        alertContainer.appendChild(alertDiv);

        setTimeout(() => {
            alertDiv.remove();
        }, 3000);
    }

    function searchOrders() {
        const input = document.getElementById('search-input');
        const filter = input.value.trim().toLowerCase();
        const rows = document.querySelectorAll('#order-list tbody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(filter));
            row.style.display = matches ? '' : 'none';
        });

        const searchBtn = document.getElementById('search-btn');
        if (filter.length > 0) {
            searchBtn.textContent = "Cancel Search";
        } else {
            searchBtn.textContent = "Search";
        }
    }

    function sortOrders(field) {
        const orderList = document.getElementById('order-list').querySelector('tbody');
        const rows = Array.from(orderList.querySelectorAll('tr'));
        const asc = field !== lastSortedField ? true : !lastSortOrder;
        lastSortedField = field;
        lastSortOrder = asc;

        rows.sort((a, b) => {
            let aValue, bValue;
            switch (field) {
                case 'id':
                    aValue = parseInt(a.querySelector('td:nth-child(2)').textContent.trim());
                    bValue = parseInt(b.querySelector('td:nth-child(2)').textContent.trim());
                    break;
                case 'supplier':
                    aValue = a.querySelector('td:nth-child(3)').textContent.trim();
                    bValue = b.querySelector('td:nth-child(3)').textContent.trim();
                    break;
                case 'delivery_date':
                    aValue = new Date(a.querySelector('td:nth-child(4)').textContent.trim());
                    bValue = new Date(b.querySelector('td:nth-child(4)').textContent.trim());
                    break;
                case 'item_name':
                    aValue = a.querySelector('td:nth-child(5)').textContent.trim();
                    bValue = b.querySelector('td:nth-child(5)').textContent.trim();
                    break;
                case 'quantity':
                    aValue = parseInt(a.querySelector('td:nth-child(6)').textContent.trim(), 10);
                    bValue = parseInt(b.querySelector('td:nth-child(6)').textContent.trim(), 10);
                    break;
                case 'price_per_unit':
                    aValue = parseFloat(a.querySelector('td:nth-child(7)').textContent.trim());
                    bValue = parseFloat(b.querySelector('td:nth-child(7)').textContent.trim());
                    break;
                case 'total':
                    aValue = parseFloat(a.querySelector('td:nth-child(8)').textContent.trim());
                    bValue = parseFloat(b.querySelector('td:nth-child(8)').textContent.trim());
                    break;
                default:
                    aValue = a.querySelector('td:nth-child(2)').textContent.trim();
                    bValue = a.querySelector('td:nth-child(2)').textContent.trim();
            }
            const comparison = (typeof aValue === 'string' && typeof bValue === 'string')
                ? aValue.localeCompare(bValue, undefined, { numeric: true })
                : aValue - bValue;
            return asc ? comparison : -comparison;
        });

        orderList.innerHTML = '';
        rows.forEach(row => orderList.appendChild(row));
    }

    function toggleReceiveReturnForm() {
        const form = document.querySelector('.inline-receive-return-form');
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }

    function toggleQuantityFields(action) {
        document.getElementById('quantity-group').style.display = action === 'Receive' || action === 'Return' ? 'block' : 'none';
    }

    function validateQuantity(quantity) {
    const totalQuantity = parseInt(document.getElementById('form-order-number').getAttribute('data-total-quantity'), 10);
    const receivedQuantity = parseInt(document.getElementById('form-order-number').getAttribute('data-received-quantity'), 10);
    const returnedQuantity = parseInt(document.getElementById('form-order-number').getAttribute('data-returned-quantity'), 10);

    const totalProcessed = receivedQuantity + returnedQuantity;
    const remainingQuantity = totalQuantity - receivedQuantity - returnedQuantity;

    if (quantity > remainingQuantity) {
        alert(`Error: The entered quantity (${quantity}) exceeds the remaining quantity (${remainingQuantity}).`);
        document.getElementById('quantity').value = '';
        return;
    }
    
    generateSerialModelInputs(quantity);
}

    function generateSerialModelInputs(quantity) {
        const container = document.getElementById('serial-model-container');
        container.innerHTML = '';  // Clear previous inputs

        // Check if the quantity is a positive number
        if (quantity > 0) {
            for (let i = 0; i < quantity; i++) {
                const serialInput = document.createElement('input');
                serialInput.type = 'text';
                serialInput.name = 'serial_numbers[]';
                serialInput.placeholder = `Serial Number ${i + 1}`;
                serialInput.required = true;
                serialInput.style.marginBottom = '10px';

                const modelInput = document.createElement('input');
                modelInput.type = 'text';
                modelInput.name = 'models[]';
                modelInput.placeholder = `Model ${i + 1}`;
                modelInput.required = true;
                modelInput.style.marginBottom = '10px';

                // Append the inputs to the container
                container.appendChild(serialInput);
                container.appendChild(modelInput);
                container.appendChild(document.createElement('br'));
            }
        } else {
            // If the quantity is invalid, clear the container
            container.innerHTML = '';
        }
    }

    function fillReceiveReturnFormFromOrder(checkbox) {
    if (checkbox.checked) {
        const row = checkbox.closest('tr');
        const orderNumber = row.querySelector('td:nth-child(2)').textContent.trim();
        const itemName = row.querySelector('td:nth-child(5)').textContent.trim();
        const supplier = row.querySelector('td:nth-child(3)').textContent.trim();
        const warranty = row.querySelector('td:nth-child(8)').textContent.trim();
        const totalQuantity = parseInt(row.querySelector('td:nth-child(6)').textContent.trim()) || 0;
        const receivedQuantity = parseInt(row.querySelector('.status').textContent.match(/Received:\s*(\d+)/)[1]) || 0;
        const returnedQuantity = parseInt(row.querySelector('.status').textContent.match(/Returned:\s*(\d+)/)[1]) || 0;

        const remainingQuantity = totalQuantity - receivedQuantity - returnedQuantity;

        fillReceiveReturnForm(orderNumber, itemName, supplier, warranty, remainingQuantity, receivedQuantity, returnedQuantity, totalQuantity);
    } else {
        clearReceiveReturnForm();
    }
}

// Fill form with data and set attributes for validation
function fillReceiveReturnForm(orderNumber, itemName, supplier, warranty, remainingQuantity, receivedQuantity, returnedQuantity, totalQuantity) {
    document.getElementById('form-order-number').value = orderNumber;
    document.getElementById('form-order-number').setAttribute('data-total-quantity', totalQuantity);
    document.getElementById('form-order-number').setAttribute('data-received-quantity', receivedQuantity);
    document.getElementById('form-order-number').setAttribute('data-returned-quantity', returnedQuantity);
    document.getElementById('form-item-name').value = itemName;
    document.getElementById('form-supplier').value = supplier;
    document.getElementById('form-warranty').value = warranty;
    document.getElementById('quantity').max = remainingQuantity;
    document.getElementById('quantity').value = '';
    document.getElementById('serial-model-container').innerHTML = '';
}
   // JavaScript to make the alert disappear after 5 seconds
   setTimeout(function() {
        var alert = document.getElementById('success-alert');
        if (alert) {
            alert.style.display = 'none'; // Hide the alert
        }
    }, 5000); // 5000 milliseconds = 5 seconds
// Clear form data when unselected
function clearReceiveReturnForm() {
    document.getElementById('form-order-number').value = '';
    document.getElementById('form-item-name').value = '';
    document.getElementById('form-supplier').value = '';
    document.getElementById('form-warranty').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('serial-model-container').innerHTML = '';
}

    function toggleCheckboxes(checkbox) {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    fillReceiveReturnFormFromOrder(checkbox);
}


    function printSelectedOrders() {
        const rows = document.querySelectorAll('#order-list tbody tr');
        let selectedOrderIds = [];

        rows.forEach(row => {
            const checkbox = row.querySelector('input[type="checkbox"]');
            if (checkbox && checkbox.checked) {
                selectedOrderIds.push(row.querySelector('td:nth-child(2)').textContent.trim());
            }
        });

        if (selectedOrderIds.length > 0) {
            fetch('fetch_order_data.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderIds: selectedOrderIds })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();

                doc.setFontSize(18);
                doc.setTextColor(40);
                doc.setFont("Helvetica", "bold");
                doc.text("Smart Touch", 20, 20);

                doc.setFontSize(12);
                doc.setFont("Helvetica", "normal");
                doc.text("Email: smart0000touch@gmail.com", 20, 30);
                doc.text("Phone: +94 76 3939 272", 20, 36);
                doc.text("Address: # Kandy Road, Sri Lanka. 20000", 20, 42);

                doc.setLineWidth(0.5);
                doc.line(20, 46, 190, 46);

                let startY = 50;
                const gap = 10;

                data.forEach(order => {
                    doc.setFontSize(16);
                    doc.setFont("Helvetica", "bold");
                    doc.text(`Invoice for Order: ${order.order_number}`, 20, startY);

                    const orderHeaders = ["Order Number", "Supplier", "Delivery Date", "Quantity", "Received Quantity", "Returned Quantity", "Warranty", "Item Name", "Unit Price", "Total"];
                    const orderBody = [
                        [
                            order.order_number,
                            order.supplier,
                            order.delivery_date,
                            order.quantity,
                            order.received_quantity,
                            order.returned_quantity,
                            order.warranty,
                            order.item_name,
                            order.price_per_unit,
                            order.total
                        ]
                    ];

                    doc.autoTable({
                        head: [orderHeaders],
                        body: orderBody,
                        startY: startY + 10,
                        theme: 'grid',
                    });

                    startY = doc.autoTable.previous.finalY + gap;

                    if (order.received_items && order.received_items.length > 0) {
                        doc.setFontSize(14);
                        doc.text("Received Items", 20, startY);
                        const receivedHeaders = ["Order Number", "Item Name", "Quantity", "Received Date", "Serial Number", "Model"];
                        const receivedBody = order.received_items.map(item => [
                            order.order_number,
                            item.item_name,
                            item.quantity,
                            item.received_date,
                            item.serial_number,
                            item.model
                        ]);

                        doc.autoTable({
                            head: [receivedHeaders],
                            body: receivedBody,
                            startY: startY + 5,
                            theme: 'grid',
                        });

                        startY = doc.autoTable.previous.finalY + gap;
                    }

                    if (order.returned_items && order.returned_items.length > 0) {
                        doc.setFontSize(14);
                        doc.text("Returned Items", 20, startY);
                        const returnedHeaders = ["Order Number", "Item Name", "Quantity", "Return Date", "Serial Number", "Model"];
                        const returnedBody = order.returned_items.map(item => [
                            order.order_number,
                            item.item_name,
                            item.quantity,
                            item.return_date,
                            item.serial_number,
                            item.model
                        ]);

                        doc.autoTable({
                            head: [returnedHeaders],
                            body: returnedBody,
                            startY: startY + 5,
                            theme: 'grid',
                        });

                        startY = doc.autoTable.previous.finalY + gap;
                    }

                    startY += 10;
                    if (startY >= 270) {
                        doc.addPage();
                        startY = 20;
                    }
                });

                doc.save(`${selectedOrderIds.join('_')}_Purchase_Order_Details.pdf`);
            })
            .catch(error => console.error('Error fetching order data:', error));
        } else {
            alert('No orders selected for printing.');
        }
    }

    let lastSortedField = '';
    let lastSortOrder = true;
    document.getElementById("currency").addEventListener("change", updateTotal);
</script>

</body>
</html>
     