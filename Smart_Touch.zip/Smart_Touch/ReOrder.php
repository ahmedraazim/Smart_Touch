<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";
include 'header.php'; 


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete stock item if delete request is made
if (isset($_GET['delete_item'])) {
    $itemId = $_GET['delete_item'];
    // Prepare the delete query to remove the item from the stock table
    $deleteQuery = $conn->prepare("DELETE FROM stock WHERE id = ?");
    $deleteQuery->bind_param("i", $itemId);

    if ($deleteQuery->execute()) {
        // Redirect to reorder.php after successful deletion
        header("Location: reorder.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $deleteQuery->close();
}

// Fetch low stock items (quantity == 0) that have not been marked as updated, or search results
$lowStockItems = [];
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$searchQuery = $searchTerm ? " AND item_name LIKE '%$searchTerm%'" : '';
$lowStockResult = $conn->query("SELECT * FROM stock WHERE quantity = 0 AND stock_updated = 0 $searchQuery ORDER BY id DESC");

if ($lowStockResult->num_rows > 0) {
    while ($row = $lowStockResult->fetch_assoc()) {
        $lowStockItems[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Re-Order Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
<Br>
<a href="Stock.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Stocks</a>

    <h2>Re-Order Listing</h2>

    <!-- Back Button -->
    <div class="d-flex justify-content-end mb-3">
        <?php
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $backUrl = (strpos($referer, 'purchase.php') !== false) ? 'purchase.php' : 'inventory.php';
        ?>
    </div>

    <!-- Search Bar -->
    <div class="mb-4">
        <form method="GET" action="reorder.php">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Search for items..." value="<?= htmlspecialchars($searchTerm) ?>">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Re-order Listing Table -->
    <h3>Low-Stock Items (Quantity = 0)</h3>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Supplier</th>
            <th>Serial Number</th>
            <th>Model</th>
            <th>Warranty</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php if (!empty($lowStockItems)): ?>
            <?php foreach ($lowStockItems as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['item_name']); ?></td>
                    <td><?= htmlspecialchars($item['quantity']); ?></td>
                    <td><?= htmlspecialchars($item['supplier']); ?></td>
                    <td><?= htmlspecialchars($item['serial_number']); ?></td>
                    <td><?= htmlspecialchars($item['model']); ?></td>
                    <td><?= htmlspecialchars($item['warranty']); ?></td>
                    <td>
                        <?php if ($item['stock_updated']): ?>
                            <span class="text-success">Stock Updated</span>
                        <?php else: ?>
                            <!-- Button to mark stock as updated and delete the item -->
                            <a href="reorder.php?delete_item=<?= $item['id']; ?>" class="btn btn-danger">Stock Updated</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7" class="text-center">No low-stock items available for reorder</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
