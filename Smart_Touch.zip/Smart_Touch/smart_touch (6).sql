-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2024 at 07:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_touch`
--

-- --------------------------------------------------------

--
-- Table structure for table `billed_items`
--

CREATE TABLE `billed_items` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `serial_number` text NOT NULL,
  `model` text NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `warranty` text DEFAULT NULL,
  `billing_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billed_items`
--

INSERT INTO `billed_items` (`id`, `order_id`, `customer_name`, `product_name`, `quantity`, `price_per_unit`, `discount`, `total`, `serial_number`, `model`, `order_number`, `warranty`, `billing_time`) VALUES
(1, 'ORD-67260d606a7ba', '12121211212', 'IdeaPad 5 Pro', 1, 12.00, 0.00, 12.00, '21', '21', 'PO-00001, PO-00001, PO-00001', '3', '2024-11-02 11:30:40'),
(2, 'ORD-672bc0933c992', 'Mohammadhu Ramsaan Ahmed Raazim', 'IdeaPad 5 Pro', 1, 11.00, 0.00, 11.00, '131', '1331', 'PO-00001, PO-00001, PO-00005', '3', '2024-11-06 19:16:35'),
(3, 'ORD-672bc2152a523', 'Mohammadhu Ramsaan Ahmed Raazim', 'IdeaPad 5 Pro', 1, 121.00, 0.00, 121.00, '12', '12', 'PO-00001, PO-00001, PO-00005', '3', '2024-11-06 19:23:01');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `phone`, `address`) VALUES
(1, 'Mohammadhu Ramsaan Ahmed Raazim', '121212', '54/1, Dikhinna, Madawala Bazaar');

-- --------------------------------------------------------

--
-- Table structure for table `customer_return`
--

CREATE TABLE `customer_return` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `warranty` varchar(255) DEFAULT NULL,
  `return_date` date NOT NULL,
  `return_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_return`
--

INSERT INTO `customer_return` (`id`, `order_id`, `customer_name`, `item_name`, `quantity`, `serial_number`, `model`, `warranty`, `return_date`, `return_reason`, `created_at`) VALUES
(112, '12121', '121212', '12121', 1, '3333333', '33333333333', '2', '2024-11-27', '121212', '2024-11-07 02:45:02'),
(113, 'ORD-672bc0933c992', 'Mohammadhu Ramsaan Ahmed Raazim', 'IdeaPad 5 Pro', 1, '131', '1331', '3', '2024-11-07', 'Received damaged', '2024-11-07 02:46:13');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `log_date` datetime DEFAULT current_timestamp(),
  `username` varchar(50) NOT NULL,
  `action` varchar(100) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','card') NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','completed') NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `order_id`, `customer_name`, `total_amount`, `amount_paid`, `payment_method`, `transaction_id`, `payment_status`, `payment_date`) VALUES
(1, 'ORD-672bc0933c992', 'Mohammadhu Ramsaan Ahmed Raazim', 0.00, 14.00, 'cash', 'INV-672bc0a1d7eb8', 'completed', '2024-11-06 19:16:49');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `product_name`) VALUES
(1, 'Laptop', 'IdeaPad 5 Pro '),
(2, 'CPU', 'PTC 7');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price_per_unit` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `received_quantity` int(11) DEFAULT 0,
  `returned_quantity` int(11) DEFAULT 0,
  `received_serial_numbers` text DEFAULT NULL,
  `returned_serial_numbers` text DEFAULT NULL,
  `received_models` text DEFAULT NULL,
  `returned_models` text DEFAULT NULL,
  `payment_status` enum('Unpaid','Paid') DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `order_number`, `supplier`, `delivery_date`, `item_name`, `quantity`, `price_per_unit`, `total`, `warranty`, `received_quantity`, `returned_quantity`, `received_serial_numbers`, `returned_serial_numbers`, `received_models`, `returned_models`, `payment_status`) VALUES
(4, 'PO-00001', '1', '2024-10-31', 'IdeaPad 5 Pro ', 5, 342.00, 1710.00, '2', 3, 2, ',21,21,21', ',53,121212', ',21,21,21', ',543,1212121', 'Unpaid'),
(5, 'PO-00002', '1', '2024-10-31', 'PTC 7', 7, 75645.00, 529515.00, '3', 4, 3, ',121212,12,32,2323', ',3,342,342', ',1212121,12,2323,2323', ',3,342,432', 'Unpaid'),
(6, 'PO-00003', 'Dell', '2024-10-31', 'PTC 7', 4, 232.00, 928.00, '2', 2, 2, ',121,2222222222', ',54,345', ',1212,2222222222222', ',34,2345', 'Paid'),
(7, 'PO-00004', 'Dell', '2024-11-05', 'PTC 7', 1, 1212.00, 1212.00, '2', 1, 0, ',1', NULL, ',1', NULL, 'Paid'),
(8, 'PO-00005', 'Dell', '2024-11-06', 'IdeaPad 5 Pro ', 4, 1533.00, 6132.00, '1', 6, 0, ',131,1331,3131', NULL, ',1331,313131,3131', NULL, 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `stock_updated` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `order_number`, `item_name`, `quantity`, `received_date`, `supplier`, `serial_number`, `model`, `warranty`, `stock_updated`) VALUES
(11, 'PO-00005', 'IdeaPad 5 Pro ', 3, '2024-11-10', NULL, '', '', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `type`, `email`, `phone`, `address`, `status`, `created_at`) VALUES
(1, 'Dell', 'Distributor', 'raazimramzaan123@gmail.com', '0763939272', '54/1, Dikhinna, Madawala Bazaar.', 'Active', '2024-10-31 13:33:47');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_pays`
--

CREATE TABLE `supplier_pays` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `received_quantity` int(11) NOT NULL,
  `returned_quantity` int(11) NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Completed') DEFAULT 'Completed',
  `transaction_id` varchar(100) NOT NULL,
  `payment_method` enum('cash','cheque') NOT NULL,
  `cheque_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_pays`
--

INSERT INTO `supplier_pays` (`id`, `order_number`, `supplier`, `item_name`, `quantity`, `received_quantity`, `returned_quantity`, `price_per_unit`, `total_amount`, `payment_date`, `status`, `transaction_id`, `payment_method`, `cheque_number`) VALUES
(16, 'PO-00004', 'Dell', 'PTC 7', 1, 1, 0, 1212.00, 1212.00, '2024-11-05 20:15:24', 'Completed', 'CASH-672a7cdc3187f', 'cash', '');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_return`
--

CREATE TABLE `supplier_return` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_return`
--

INSERT INTO `supplier_return` (`id`, `order_number`, `item_name`, `quantity`, `return_date`, `supplier`, `serial_number`, `model`, `warranty`) VALUES
(1, 'PO-00002', 'PTC 7', 1, '2024-10-31', '1', '3', '3', '3'),
(2, 'PO-00001', 'IdeaPad 5 Pro', 1, '2024-10-31', '1', '53', '543', '2'),
(3, 'PO-00001', 'IdeaPad 5 Pro', 1, '2024-10-31', '1', '121212', '1212121', '2'),
(4, 'PO-00003', 'PTC 7', 2, '2024-10-31', 'Dell', '54,345', '34,2345', '2'),
(5, 'PO-00002', 'PTC 7', 2, '2024-11-05', '1', '342,342', '342,432', '3');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `transaction_type` enum('purchase','sale') NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `supplier_name` varchar(100) DEFAULT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `transaction_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `warranty_returns`
--

CREATE TABLE `warranty_returns` (
  `return_id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `return_date` date NOT NULL,
  `warranty_end_date` date NOT NULL,
  `comments` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_handed_over` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warranty_returns`
--

INSERT INTO `warranty_returns` (`return_id`, `order_id`, `product_name`, `customer_name`, `return_date`, `warranty_end_date`, `comments`, `created_at`, `is_handed_over`) VALUES
(2, 'ORD-67260d606a7ba', 'IdeaPad 5 Pro', '12121211212', '2024-11-06', '2025-02-02', 'hard disk error', '2024-11-06 09:50:19', 1),
(3, 'ORD-67260d606a7ba', 'IdeaPad 5 Pro', '12121211212', '2024-11-06', '2025-02-02', 'asasa', '2024-11-06 14:14:35', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billed_items`
--
ALTER TABLE `billed_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `customer_return`
--
ALTER TABLE `customer_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_pays`
--
ALTER TABLE `supplier_pays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_return`
--
ALTER TABLE `supplier_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `warranty_returns`
--
ALTER TABLE `warranty_returns`
  ADD PRIMARY KEY (`return_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billed_items`
--
ALTER TABLE `billed_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_return`
--
ALTER TABLE `customer_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `supplier_pays`
--
ALTER TABLE `supplier_pays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `supplier_return`
--
ALTER TABLE `supplier_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warranty_returns`
--
ALTER TABLE `warranty_returns`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
