<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Touch Inventory</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom Styles -->
    <style>
        body {
            background-color: #f4f6f9;
            color: #333;
            font-size: 18px;
        }

        header {
            background-color: #16325B;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 5px solid #fff;
            border-radius: 10px;
        }

        .header-icon {
            font-size: 36px;
            margin-right: 15px;
        }

        .header-title {
            font-size: 24px;
            font-weight: bold;
        }

        /* Prevent header interference with page functionality */
        .container {
            margin-top: 20px; /* Adjust spacing to avoid overlap */
        }
    </style>
</head>
<body>
    <header>
        <i class="bi bi-box-seam header-icon"></i> <!-- Icon using Bootstrap Icons -->
        <span class="header-title">Smart Touch Inventory</span>
    </header>
    <!-- Ensure container compatibility -->
    <div class="container">
