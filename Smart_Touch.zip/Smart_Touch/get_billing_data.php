<?php
include 'db_connection.php';

if (isset($_POST['billingId'])) {
    $billingId = $_POST['billingId'];

    // Fetch the billing data
    $query = $conn->prepare("SELECT * FROM billed_items WHERE id = ?");
    $query->bind_param("i", $billingId);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $billing = $result->fetch_assoc();
        echo json_encode($billing);
    } else {
        echo json_encode(['error' => 'Billing not found']);
    }
}
?>
