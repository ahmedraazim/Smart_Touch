<?php
header('Content-Type: application/json');
include 'db_connection.php';

$response = ['success' => false];

// Fetch Total Products
$totalProductsQuery = $conn->query("SELECT COUNT(*) as total FROM products");
$totalProducts = $totalProductsQuery->fetch_assoc()['total'] ?? 0;

// Fetch Total Orders
$totalOrdersQuery = $conn->query("SELECT COUNT(*) as total FROM orders");
$totalOrders = $totalOrdersQuery->fetch_assoc()['total'] ?? 0;

// Fetch Low Stock Count
$lowStockQuery = $conn->query("SELECT COUNT(*) as total FROM products WHERE quantity < reorder_level");
$lowStockCount = $lowStockQuery->fetch_assoc()['total'] ?? 0;

// Fetch Out of Stock Count
$outOfStockQuery = $conn->query("SELECT COUNT(*) as total FROM products WHERE quantity = 0");
$outOfStockCount = $outOfStockQuery->fetch_assoc()['total'] ?? 0;

// Fetch Stock Data
$stockDataQuery = $conn->query("SELECT item_name, quantity FROM products");
$stockData = [];
while ($row = $stockDataQuery->fetch_assoc()) {
    $stockData[] = $row;
}

// Fetch Supplier Data
$supplierDataQuery = $conn->query("SELECT supplier, COUNT(*) as order_count FROM orders GROUP BY supplier");
$supplierData = [];
while ($row = $supplierDataQuery->fetch_assoc()) {
    $supplierData[] = $row;
}

// Prepare the response
$response = [
    'success' => true,
    'totalProducts' => $totalProducts,
    'totalOrders' => $totalOrders,
    'lowStockCount' => $lowStockCount,
    'outOfStockCount' => $outOfStockCount,
    'stockData' => $stockData,
    'supplierData' => $supplierData
];

// Send JSON response
echo json_encode($response);
?>
