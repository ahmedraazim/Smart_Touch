<?php
session_start();
include 'db_connection.php'; // Include your database connection file

require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Initialize variables
$orderId = $_GET['order_id'] ?? null;
$customerName = $_GET['customerName'] ?? null;
$totalAmount = $_GET['totalAmount'] ?? null;

// Check for required parameters
if (!$orderId || !$customerName || !$totalAmount) {
    die("Invalid request.");
}

// Function to generate and download invoice using Dompdf
function generateInvoice($conn, $orderId, $customerName, $totalAmount) {
    // Fetch billed items from the billed_items table
    $stmt = $conn->prepare("SELECT product_name, quantity, price_per_unit, total FROM billed_items WHERE order_id = ?");
    $stmt->bind_param("s", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Create PDF using Dompdf
    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);

    // HTML for the invoice
    $html = '
    <style>
        body {
            font-family: "Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif;
            text-align: center;
            color: #777;
        }
        h1 {
            color: #396EB0;
            font-size: 36px;
            margin: 0;
        }
        h2 {
            color: #396EB0;
            font-size: 24px;
            margin-bottom: 0;
        }
        table {
            width: 100%;
            text-align: left;
            border-collapse: collapse;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #396EB0;
            color: white;
        }
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        }
        .invoice-details {
            margin-top: 30px;
            text-align: right;
            font-size: 16px;
        }
        .total {
            font-weight: bold;
            font-size: 18px;
        }
    </style>

    <div class="invoice-box">
        <h1>Smart Touch</h1>
        <h2>Invoice</h2>

        <table>
            <tr>
                <td>
                    <strong>Customer Name:</strong> ' . htmlspecialchars($customerName) . '<br>
                </td>
                <td class="invoice-details">
                    <strong>Invoice #:</strong> ' . htmlspecialchars($orderId) . '<br>
                    <strong>Created:</strong> ' . date('F d, Y') . '<br>
                    <strong>Total:</strong> $' . number_format($totalAmount, 2) . '
                </td>
            </tr>
        </table>

        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price per Unit</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>';

    // Add each billed item to the invoice
    while ($row = $result->fetch_assoc()) {
        $html .= "<tr>
                    <td>" . htmlspecialchars($row['product_name']) . " (x" . htmlspecialchars($row['quantity']) . ")</td>
                    <td>" . htmlspecialchars($row['quantity']) . "</td>
                    <td>$" . number_format($row['price_per_unit'], 2) . "</td>
                    <td>$" . number_format($row['total'], 2) . "</td>
                  </tr>";
    }

    $html .= '
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="total">Total:</td>
                    <td class="total">$' . number_format($totalAmount, 2) . '</td>
                </tr>
            </tfoot>
        </table>
    </div>';

    // Load the HTML content into Dompdf
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    // Stream the generated PDF to the browser and force download
    $dompdf->stream("invoice_$orderId.pdf", ['Attachment' => true]);
    exit;
}

// Call the function to generate the invoice
generateInvoice($conn, $orderId, $customerName, $totalAmount);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Invoice for Order: <?= htmlspecialchars($orderId) ?></h2>
    <p>Customer Name: <?= htmlspecialchars($customerName) ?></p>
    <p>Total Amount: $<?= number_format($totalAmount, 2) ?></p>
    <a href="payment.php?order_id=<?= urlencode($orderId) ?>&customerName=<?= urlencode($customerName) ?>&totalAmount=<?= $totalAmount ?>" class="btn btn-primary">Go Back to Payment</a>
</div>
</body>
</html>
