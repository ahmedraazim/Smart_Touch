<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$showResetForm = false;

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $inputUsername = $_POST['username'];
    $inputPassword = $_POST['password'];
    $role = $_POST['role'];
    $stmt = $conn->prepare("SELECT password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $inputUsername);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($dbPassword, $dbRole);
        $stmt->fetch();
        if ($inputPassword === $dbPassword && $role === $dbRole) {
            $_SESSION['role'] = $dbRole;
            $_SESSION['username'] = $inputUsername;
            $logStmt = $conn->prepare("INSERT INTO logs (username, action, details) VALUES (?, ?, ?)");
            $logAction = "Login";
            $logDetails = "User logged in successfully.";
            $logStmt->bind_param("sss", $inputUsername, $logAction, $logDetails);
            $logStmt->execute();
            $logStmt->close();
            if ($dbRole === 'admin') {     header("Location: admin.php");
            } else {     header("Location: inventory.php");
            }
            exit();
        } else {            $error = "Invalid credentials!";
        }
    } else {        $error = "Invalid credentials!";
    }
    $stmt->close();
}

// Handle forgot password form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['forgot_password'])) {
    $inputUsername = $_POST['forgot_username'];
    $inputEmail = $_POST['forgot_email'];
    $inputPhoneNumber = $_POST['forgot_phone_number'];

    $stmt = $conn->prepare("SELECT email, phone_number FROM users WHERE username = ?");
    $stmt->bind_param("s", $inputUsername);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($dbEmail, $dbPhoneNumber);
        $stmt->fetch();

        if ($inputEmail === $dbEmail && $inputPhoneNumber === $dbPhoneNumber) {
            $_SESSION['reset_username'] = $inputUsername;
            header("Location: reset_password.php");
            exit();
        } else {
            $error = "Invalid email or phone number!";
        }
    } else {
        $error = "No user found with that username!";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(to right, #0066cc, #00408e);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        header {
            background-color: #00408e;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: absolute;
            width: 100%;
            top: 0;
        }
        .header-title {
            font-size: 24px;
        }
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 20px;
            color: #00408e;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #00408e;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border 0.3s;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #0066cc;
            outline: none;
        }
        .login-button, .forgot-button {
            width: 100%;
            padding: 10px;
            background-color: #00408e;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }
        .login-button:hover, .forgot-button:hover {
            background-color: #0066cc;
        }
        .error {
            color: white;
            background-color: red;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .forgot-link {
            margin-top: 10px;
            font-size: 14px;
            color: #00408e;
            cursor: pointer;
            text-decoration: underline;
        }
        footer {
            background-color: #00408e;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style> 
    <script>
        function showForgotPasswordForm() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('forgotPasswordForm').style.display = 'block';
        }
    </script>
</head>
<body>

<header style="display: flex; justify-content: center; align-items: center;">
    <div style="display: flex; align-items: center;">
        <img src="logo/Batch.PNG" alt="Logo" width="50">
        <span class="header-title">Smart Touch</span>
    </div>
</header>


<div class="login-container">
    <h2>Login</h2>
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Login Form -->
    <form id="loginForm" method="POST" action="login.php">
        <div class="form-group">
            <label for="role">Role</label>
            <select name="role" required>
                <option value="" disabled selected>Select your role</option>
                <option value="admin">Admin</option>
                <option value="staff">Staff</option>
            </select>
        </div>
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" class="login-button" name="login">Login</button>
        <div class="forgot-link" onclick="showForgotPasswordForm()">Forgot Password?</div>
    </form>

    <!-- Forgot Password Form -->
    <form id="forgotPasswordForm" method="POST" action="login.php" style="display: none;">
        <div class="form-group">
            <label for="forgot_username">Username</label>
            <input type="text" name="forgot_username" required>
        </div>
        <div class="form-group">
            <label for="forgot_email">Email</label>
            <input type="email" name="forgot_email" required>
        </div>
        <div class="form-group">
            <label for="forgot_phone_number">Phone Number</label>
            <input type="text" name="forgot_phone_number" required>
        </div>
        <button type="submit" class="forgot-button" name="forgot_password">Reset Password</button>
    </form>
</div>

<footer>
    &copy; 2024 Smart Touch Inventory. All rights reserved.
</footer>

</body>
</html>
