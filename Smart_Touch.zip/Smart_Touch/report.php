<?php
require 'vendor/autoload.php';
use Dompdf\Dompdf;
include_once("header.php");

// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'smart_touch';
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch KPI data
$totalProducts = $conn->query("SELECT COUNT(DISTINCT id) as total FROM products")->fetch_assoc()['total'] ?? 0;
$totalSellingOrders = $conn->query("SELECT COUNT(DISTINCT order_id) as total FROM billed_items")->fetch_assoc()['total'] ?? 0;
$totalSales = $conn->query("SELECT SUM(total) as total FROM billed_items")->fetch_assoc()['total'] ?? 0;
$totalReturns = $conn->query("SELECT COUNT(DISTINCT return_id) as total FROM warranty_returns")->fetch_assoc()['total'] ?? 0;

// Fetch data for charts
$stockData = $conn->query("SELECT item_name, SUM(quantity) as quantity FROM stock GROUP BY item_name")->fetch_all(MYSQLI_ASSOC);
$supplierData = $conn->query("SELECT supplier, COUNT(*) as order_count FROM purchase_orders GROUP BY supplier")->fetch_all(MYSQLI_ASSOC);
$topCustomers = $conn->query("SELECT customer_name, SUM(total) as total_spent FROM billed_items GROUP BY customer_name ORDER BY total_spent DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$warrantyDurations = $conn->query("SELECT warranty, COUNT(*) as count FROM stock GROUP BY warranty")->fetch_all(MYSQLI_ASSOC);
$topSellingProducts = $conn->query("SELECT product_name, SUM(quantity) as total_sold FROM billed_items GROUP BY product_name ORDER BY total_sold DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);

// Day-wise sales data
$salesData = $conn->query("SELECT DATE_FORMAT(billing_time, '%Y-%m-%d') as day, SUM(total) as sales FROM billed_items GROUP BY day ORDER BY day ASC")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Touch Inventory Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }
        .kpi-card {
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .chart-container {
            padding: 20px;
            margin-top: 20px;
        }
        canvas {
            width: 100% !important;
            max-height: 300px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1 class="mt-4 mb-4 text-center">Smart Touch Inventory Dashboard</h1>
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
    
    <!-- KPI Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="kpi-card bg-primary">Total Products<br><h2><?= $totalProducts ?></h2></div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card bg-success">Total Selling Orders<br><h2><?= $totalSellingOrders ?></h2></div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card bg-info">Total Sales<br><h2>Rs. <?= number_format($totalSales, 2) ?></h2></div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card bg-danger">Total Returns<br><h2><?= $totalReturns ?></h2></div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row">
        <div class="col-md-6 chart-container">
            <h5>Stock Quantity by Item</h5>
            <canvas id="stockChart"></canvas>
        </div>
        <div class="col-md-6 chart-container">
            <h5>Orders by Supplier</h5>
            <canvas id="supplierChart"></canvas>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 chart-container">
            <h5>Top Customers by Spending</h5>
            <canvas id="topCustomersChart"></canvas>
        </div>
        <div class="col-md-6 chart-container">
            <h5>Most Common Warranty Durations</h5>
            <canvas id="warrantyChart"></canvas>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 chart-container">
            <h5>Top Selling Products</h5>
            <canvas id="topSellingChart"></canvas>
        </div>
        <div class="col-md-6 chart-container">
            <h5>Day-wise Sales Trend</h5>
            <canvas id="salesTrendChart"></canvas>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Render Charts
    renderBarChart('stockChart', <?= json_encode($stockData) ?>, 'item_name', 'quantity', '#36A2EB');
    renderBarChart('supplierChart', <?= json_encode($supplierData) ?>, 'supplier', 'order_count', '#FF6384');
    renderBarChart('topCustomersChart', <?= json_encode($topCustomers) ?>, 'customer_name', 'total_spent', '#36A2EB');
    renderPieChart('warrantyChart', <?= json_encode($warrantyDurations) ?>, 'warranty', 'count', ['#FF6384', '#36A2EB', '#FFCE56']);
    renderBarChart('topSellingChart', <?= json_encode($topSellingProducts) ?>, 'product_name', 'total_sold', '#FF6384');
    renderBarChart('salesTrendChart', <?= json_encode($salesData) ?>, 'day', 'sales', '#4BC0C0');
});

// Bar Chart
function renderBarChart(id, data, labelKey, valueKey, color) {
    new Chart(document.getElementById(id), {
        type: 'bar',
        data: {
            labels: data.map(d => d[labelKey]),
            datasets: [{
                label: valueKey,
                data: data.map(d => d[valueKey]),
                backgroundColor: color,
            }]
        },
        options: { responsive: true }
    });
}

// Pie Chart
function renderPieChart(id, data, labelKey, valueKey, colors) {
    new Chart(document.getElementById(id), {
        type: 'pie',
        data: {
            labels: data.map(d => d[labelKey]),
            datasets: [{
                data: data.map(d => d[valueKey]),
                backgroundColor: colors,
            }]
        },
        options: { responsive: true }
    });
}
</script>
</body>
</html>
