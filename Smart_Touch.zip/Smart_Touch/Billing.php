<?php
session_start();
include 'db_connection.php'; // Include your database connection file

// Initialize message variables
$successMessage = "";
$errorMessage = "";
$redirectToPayment = false;
$orderId = "";
$totalAmount = 0; // Initialize total amount

// Fetch product names from the stock table for the dropdown
$productQuery = $conn->query("SELECT DISTINCT item_name FROM stock");
$products = [];
if ($productQuery->num_rows > 0) {
    while ($row = $productQuery->fetch_assoc()) {
        $products[] = $row['item_name'];
    }
}

// Handle the AJAX request to fetch serial numbers, models, order numbers, and warranties
if (isset($_POST['fetch_serials_models'])) {
    $productName = $_POST['productName'];
    $quantity = (int)$_POST['quantity']; // Ensure quantity is an integer

    $query = $conn->prepare("SELECT serial_number, model, quantity, order_number, warranty FROM stock WHERE item_name = ?");
    $query->bind_param('s', $productName);
    $query->execute();
    $result = $query->get_result();

    $response = [
        'serials' => [],
        'models' => [],
        'order_numbers' => [],
        'warranties' => [],
        'quantity' => 0 // Total available quantity
    ];

    $totalAvailableQuantity = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $serials = explode(",", $row['serial_number']);
            $models = explode(",", $row['model']);
            $warranty = $row['warranty'];
            $order_number = $row['order_number'];
            $availableQuantity = (int)$row['quantity'];

            $totalAvailableQuantity += $availableQuantity;

            if ($totalAvailableQuantity >= $quantity) {
                $response['serials'] = array_slice($serials, 0, $quantity);
                $response['models'] = array_slice($models, 0, $quantity);
                $response['order_numbers'][] = $order_number;
                $response['warranties'][] = $warranty;
                $response['quantity'] = $totalAvailableQuantity;
                break;
            }
        }

        if ($totalAvailableQuantity < $quantity) {
            $response = ['status' => 'out_of_stock'];
        }
    } else {
        $response = ['status' => 'out_of_stock'];
    }

    echo json_encode($response);
    exit;
}

// Process the billing form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['billingSubmit'])) {
    $customerName = $conn->real_escape_string($_POST['customerName']);
    $customerPhone = $conn->real_escape_string($_POST['customerPhone']);
    $customerAddress = $conn->real_escape_string($_POST['customerAddress']);
    $billingItems = json_decode($_POST['items'], true); // Data from the billing summary table

    // Start a transaction to ensure atomicity
    $conn->begin_transaction();

    try {
        // Insert or update customer information in the 'customers' table
        $customerQuery = $conn->prepare("SELECT id FROM customers WHERE phone = ?");
        $customerQuery->bind_param("s", $customerPhone);
        $customerQuery->execute();
        $customerResult = $customerQuery->get_result();

        if ($customerResult->num_rows > 0) {
            // Customer exists, update their information
            $updateCustomer = $conn->prepare("UPDATE customers SET name = ?, address = ? WHERE phone = ?");
            $updateCustomer->bind_param("sss", $customerName, $customerAddress, $customerPhone);
            $updateCustomer->execute();
        } else {
            // Insert new customer
            $insertCustomer = $conn->prepare("INSERT INTO customers (name, phone, address) VALUES (?, ?, ?)");
            $insertCustomer->bind_param("sss", $customerName, $customerPhone, $customerAddress);
            $insertCustomer->execute();
        }

        if (is_array($billingItems) && !empty($billingItems)) {
            $orderId = uniqid('ORD-'); // Unique order ID for billing
            $totalAmount = 0; // Variable to calculate the total amount for the payment

            // Process each billed item
            foreach ($billingItems as $item) {
                if (isset($item['name'], $item['quantity'], $item['price_per_unit'], $item['serial_numbers'], $item['models'], $item['order_number'], $item['warranty'])) {
                    $productName = $item['name'];
                    $quantity = (int)$item['quantity'];
                    $pricePerUnit = (float)$item['price_per_unit'];
                    $discount = (float)$item['discount'];
                    $total = (float)$item['total'];

                    // Add the total for this item to the total amount for the payment
                    $totalAmount += $total;

                    // Ensure warranty is a string (handle as needed)
                    if (is_array($item['warranty'])) {
                        $warranty = implode(',', $item['warranty']);
                    } else {
                        $warranty = $item['warranty'];
                    }

                    $serialNumbers = $item['serial_numbers']; // Keep as an array
                    $models = $item['models']; // Keep as an array
                    $orderNumber = $item['order_number'];

                    // Insert into billed_items table with billing_time
                    $serialNumbersString = implode(',', $serialNumbers);
                    $modelsString = implode(',', $models);

                    $stmt = $conn->prepare("INSERT INTO billed_items (order_id, customer_name, product_name, quantity, price_per_unit, discount, total, serial_number, model, order_number, warranty, billing_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->bind_param("sssiddsssss", $orderId, $customerName, $productName, $quantity, $pricePerUnit, $discount, $total, $serialNumbersString, $modelsString, $orderNumber, $warranty);

                    if (!$stmt->execute()) {
                        throw new Exception("Error saving to billed_items: " . $stmt->error);
                    }

                    // Update stock
                    updateStock($conn, $productName, $serialNumbers, $models, $quantity);
                }
            }

            // Commit the transaction
            $conn->commit();
            $successMessage = "Billing successful, items billed, and stock updated!";
            $redirectToPayment = true; // Set this to true to trigger the payment redirection
        } else {
            throw new Exception("No items were provided in the billing.");
        }
    } catch (Exception $e) {
        // Rollback the transaction in case of an error
        $conn->rollback();
        $errorMessage = $e->getMessage();
    }

    // Redirect to payment page if billing is successful
    if ($redirectToPayment) {
        // Ensure no output before header
        if (!headers_sent()) {
            header("Location: payment.php?order_id=$orderId&customerName=$customerName&totalAmount=$totalAmount");
            exit();
        } else {
            echo "<script>window.location.href = 'payment.php?order_id=$orderId&customerName=$customerName&totalAmount=$totalAmount';</script>";
            exit();
        }
    }
}

// Function to update the stock table
function updateStock($conn, $productName, $serialNumbers, $models, $quantityToRemove) {
    // Fetch the existing stock data
    $query = $conn->prepare("SELECT serial_number, model, quantity FROM stock WHERE item_name = ?");
    $query->bind_param('s', $productName);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $existingSerialNumbers = explode(",", $row['serial_number']);
        $existingModels = explode(",", $row['model']);
        $existingQuantity = (int)$row['quantity'];
        // Remove the serial numbers and models that were billed
        $updatedSerialNumbers = array_diff($existingSerialNumbers, $serialNumbers);
        $updatedModels = array_diff($existingModels, $models);
        $updatedQuantity = $existingQuantity - $quantityToRemove;
        if ($updatedQuantity > 0) {
            // Update the stock with the new serial numbers and models
            $updatedSerialNumbersString = implode(",", $updatedSerialNumbers);
            $updatedModelsString = implode(",", $updatedModels);
            $updateQuery = $conn->prepare("UPDATE stock SET serial_number = ?, model = ?, quantity = ? WHERE item_name = ?");
            $updateQuery->bind_param("ssis", $updatedSerialNumbersString, $updatedModelsString, $updatedQuantity, $productName);
            if (!$updateQuery->execute()) {
                throw new Exception("Error updating stock: " . $updateQuery->error);
            }
        } else {
            // If quantity becomes zero, remove the product from stock
            $deleteQuery = $conn->prepare("DELETE FROM stock WHERE item_name = ?");
            $deleteQuery->bind_param("s", $productName);
            if (!$deleteQuery->execute()) {
                throw new Exception("Error deleting stock: " . $deleteQuery->error);
            }
        }
    } else {
        throw new Exception("Product not found in stock.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
                    <!-- Back to Home Button -->
                    <div class="mb-3">
                    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
                    </div>
    <h2 class="text-center mb-4">Billing</h2>

    <!-- Success and Error Messages -->
    <div id="message-box">
        <?php if (!empty($successMessage)): ?>
            <div class="alert alert-success" id="successMessage">
                <?= $successMessage; ?>
            </div>
        <?php elseif (!empty($errorMessage)): ?>
            <div class="alert alert-danger">
                <?= $errorMessage; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Customer Information -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Customer Information</div>
        <div class="card-body">
            <form id="billingForm" method="POST" action="billing.php">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="customerName" class="form-label">Customer Name</label>
                        <input type="text" class="form-control" name="customerName" id="customerName" required>
                    </div>
                    <div class="col-md-6">
                        <label for="customerPhone" class="form-label">Phone</label>
                        <input type="text" class="form-control" name="customerPhone" id="customerPhone" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="customerAddress" class="form-label">Address</label>
                    <input type="text" class="form-control" name="customerAddress" id="customerAddress" required>
                </div>

                <!-- Add Product Button -->
                <button type="button" id="addProductButton" class="btn btn-success mb-3" onclick="showProductForm()">Add Product</button>

                <!-- Product Inputs (Initially Hidden) -->
                <div id="productForm" style="display: none;">
                    <h4 class="my-3">Add Products</h4>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="productName" class="form-label">Product Name</label>
                            <select class="form-select" id="productName" required>
                                <option value="" disabled selected>Select Product</option>
                                <?php foreach ($products as $product): ?>
                                    <option value="<?= htmlspecialchars($product); ?>"><?= htmlspecialchars($product); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="productQty" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="productQty" placeholder="Qty" required onchange="fetchSerialsAndModels()">
                        </div>
                        <div class="col-md-2">
                            <label for="productPrice" class="form-label">Price per Unit</label>
                            <input type="number" class="form-control" id="productPrice" placeholder="Price" required>
                        </div>
                        <div class="col-md-2">
                            <label for="productDiscount" class="form-label">Discount (%)</label>
                            <input type="number" class="form-control" id="productDiscount" placeholder="Discount" value="0">
                        </div>
                    </div>

                    <!-- Dynamic Serial Numbers, Models, and Warranties -->
                    <div id="dynamicInputs"></div>

                    <input type="hidden" id="orderNumber" name="orderNumber" /> <!-- Hidden field for order number -->
                    <input type="hidden" id="items" name="items" /> <!-- Hidden field to store items -->

                    <!-- Out of Stock Message -->
                    <div id="outOfStockMessage" class="alert alert-danger" style="display: none;">Out of Stock</div>

                    <!-- Add Product Button (inside form) -->
                    <button type="button" class="btn btn-primary" onclick="addProduct()">Add to Billing Summary</button>
                </div>

                <!-- Billing Summary -->
                <h4>Billing Summary</h4>
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Price per Unit</th>
                            <th>Discount (%)</th>
                            <th>Total</th>
                            <th>Serial Numbers</th>
                            <th>Models</th>
                            <th>Warranty</th>
                            <th>Order Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="billingTable">
                        <!-- Items will be added here dynamically -->
                    </tbody>
                </table>

                <!-- Submit Button -->
                <div class="d-flex justify-content-between">
                    <button type="submit" name="billingSubmit" class="btn btn-primary">Submit Billing</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/js/select2.min.js"></script>
<script>
    // Show the product form when the "Add Product" button is clicked
    function showProductForm() {
        document.getElementById('productForm').style.display = 'block';
        document.getElementById('addProductButton').disabled = true; // Disable add product button until the form is submitted
    }

    // Fetch serials, models, and warranties based on selected product name and quantity
    function fetchSerialsAndModels() {
        const productName = document.getElementById('productName').value;
        const quantity = document.getElementById('productQty').value;

        // Clear any previous 'Out of Stock' message and reset fields
        document.getElementById('outOfStockMessage').style.display = 'none';

        if (!productName || !quantity) {
            return; // Don't do anything if no product is selected or quantity is not provided
        }

        fetch('billing.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ fetch_serials_models: true, productName, quantity })
        })
        .then(response => response.json())
        .then(data => {
            const orderNumberField = document.getElementById('orderNumber'); // Hidden field to store order number(s)
            const quantityField = document.getElementById('productQty'); // Field to track the available quantity

            if (data.status === 'out_of_stock') {
                document.getElementById('outOfStockMessage').style.display = 'block'; // Show 'Out of Stock' message
                return;
            }

            document.getElementById('outOfStockMessage').style.display = 'none'; // Hide 'Out of Stock' message

            // Populate the serial numbers, models, and warranties in the dropdowns
            let serials = data.serials;
            let models = data.models;
            let warranties = data.warranties;
            let availableQuantity = data.quantity;
            let orderNumbers = data.order_numbers.join(", "); // Combine multiple order numbers

            if (parseInt(quantityField.value) > availableQuantity) {
                alert(`Only ${availableQuantity} items are available in stock`);
                quantityField.value = availableQuantity; // Set max available quantity
            }

            orderNumberField.value = orderNumbers; // Store the order number

            // Initialize the dynamic inputs
            initializeDynamicInputs(serials, models, warranties, quantityField.value);
        })
        .catch(error => console.error('Error fetching data:', error));
    }

    // Function to initialize dynamic inputs for serial numbers, models, and warranties
    function initializeDynamicInputs(serials, models, warranties, quantity) {
        const dynamicInputs = document.getElementById('dynamicInputs');
        dynamicInputs.innerHTML = ''; // Clear existing inputs

        for (let i = 0; i < quantity; i++) {
            dynamicInputs.innerHTML += `
                <div class="row mb-2">
                    <div class="col-md-3">
                        <label for="serialNumber${i}" class="form-label">Serial Number ${i + 1}</label>
                        <select class="form-select" id="serialNumber${i}" required>
                            <option value="" disabled selected>Select Serial</option>
                            ${serials.map(serial => `<option value="${serial}">${serial}</option>`).join('')}
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="model${i}" class="form-label">Model ${i + 1}</label>
                        <select class="form-select" id="model${i}" required>
                            <option value="" disabled selected>Select Model</option>
                            ${models.map(model => `<option value="${model}">${model}</option>`).join('')}
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="warranty${i}" class="form-label">Warranty ${i + 1}</label>
                        <input type="text" class="form-control" id="warranty${i}" value="${warranties[i]}" readonly>
                    </div>
                </div>
            `;
        }

        // Reinitialize the select2 for dynamic inputs
        $('.form-select').select2();
    }

    // Function to add product to the billing summary without refreshing
    function addProduct() {
        const productName = document.getElementById('productName').value;
        const productQty = document.getElementById('productQty').value;
        const productPrice = document.getElementById('productPrice').value;
        const productDiscount = document.getElementById('productDiscount').value || 0;
        const orderNumber = document.getElementById('orderNumber').value;

        let serialNumbers = [];
        let models = [];
        let warranties = [];

        for (let i = 0; i < productQty; i++) {
            const serialNumber = document.getElementById(`serialNumber${i}`).value;
            const model = document.getElementById(`model${i}`).value;
            const warranty = document.getElementById(`warranty${i}`).value;
            if (serialNumber && model && warranty) {
                serialNumbers.push(serialNumber);
                models.push(model);
                warranties.push(warranty);
            }
        }

        if (productName && productQty && productPrice && serialNumbers.length > 0 && models.length > 0 && warranties.length > 0 && orderNumber) {
            const total = (productQty * productPrice) * ((100 - productDiscount) / 100);
            const billingTable = document.getElementById('billingTable');

            // Add new row to the summary table without refreshing
            const row = billingTable.insertRow();
            row.innerHTML = `
                <td>${productName}</td>
                <td>${productQty}</td>
                <td>${productPrice}</td>
                <td>${productDiscount}</td>
                <td>${total.toFixed(2)}</td>
                <td>${serialNumbers.join(", ")}</td>
                <td>${models.join(", ")}</td>
                <td>${warranties.join(", ")}</td>
                <td>${orderNumber}</td>
                <td><button type="button" class="btn btn-danger" onclick="removeProduct(this)">Remove</button></td>
            `;

            // Update the hidden field for 'items' in the form
            let items = JSON.parse(document.getElementById('items').value || '[]');
            items.push({
                name: productName,
                quantity: productQty,
                price_per_unit: productPrice,
                discount: productDiscount,
                total: total,
                serial_numbers: serialNumbers,
                models: models,
                warranty: warranties,
                order_number: orderNumber
            });

            document.getElementById('items').value = JSON.stringify(items);

            // Keep the product details in the form intact, but hide the product form
            document.getElementById('productForm').style.display = 'none'; // Hide the product form
            document.getElementById('addProductButton').disabled = false; // Re-enable the add product button
        } else {
            alert('Please fill in all product details');
        }
    }

    // Function to remove product from the billing summary
    function removeProduct(button) {
        const row = button.parentNode.parentNode;
        const productName = row.cells[0].innerText;
        const serialNumbers = row.cells[5].innerText.split(', ');

        // Remove the item from the hidden 'items' field
        let items = JSON.parse(document.getElementById('items').value || '[]');
        items = items.filter(item => !(item.name === productName && item.serial_numbers.toString() === serialNumbers.toString()));
        document.getElementById('items').value = JSON.stringify(items);

        // Remove the row from the billing table
        row.parentNode.removeChild(row);
    }

    // Form validation to prevent submission without products
    function validateForm() {
        const itemsField = document.getElementById('items').value;
        if (!itemsField || itemsField.length === 0) {
            alert("Please add at least one product before submitting.");
            return false;
        }
        return true;
    }

    // Attach validation to the form submit event
    document.getElementById('billingForm').addEventListener('submit', function(event) {
        if (!validateForm()) {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });

    // Success message fadeout after few seconds
    $(document).ready(function() {
        $("#successMessage").fadeTo(2000, 500).slideUp(500, function(){
            $(this).remove();
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
