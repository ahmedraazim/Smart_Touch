<?php
// Include header and database connection files
include_once("header.php");
include_once("config.php");

// Initialize variables
$warrantyData = [];
$returnSearch = $_GET['returnSearch'] ?? '';
$searchOrderID = $_GET['searchOrderID'] ?? '';

// Handle warranty return submission and "Hand Over" action
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === 'return') {
        // Capture return form data
        $orderID = $_POST['orderID'];
        $productName = $_POST['productName'];
        $customerName = $_POST['customerName'];
        $warrantyEndDate = $_POST['warrantyEndDate'];
        $comments = $_POST['comments'];
        $returnDate = date('Y-m-d');
        $stmt = $conn->prepare("INSERT INTO warranty_returns 
        (order_id, product_name, customer_name, return_date, warranty_end_date, comments) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $orderID, $productName, $customerName, $returnDate, $warrantyEndDate, $comments);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Warranty return recorded successfully.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
        $stmt->close();
    } elseif ($action === 'hand_over') {
        $returnID = $_POST['returnID'];
        $stmt = $conn->prepare("UPDATE warranty_returns SET is_handed_over = TRUE WHERE return_id = ?");
        $stmt->bind_param("s", $returnID);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Marked as handed over to supplier.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }
}

// Fetch warranty data based on order ID search
if ($searchOrderID) {
    $stmt = $conn->prepare("SELECT *, DATE_ADD(billing_time, INTERVAL warranty MONTH) AS warranty_end_date FROM billed_items WHERE order_id LIKE ?");
    $searchTerm = "%$searchOrderID%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $row['warranty_end_date'] = date('Y-m-d', strtotime($row['billing_time'] . " + {$row['warranty']} months"));
        $warrantyData[] = $row;
    }
    $stmt->close();
}

// Fetch warranty returns based on search criteria
$sql = "SELECT * FROM warranty_returns";
if ($returnSearch) {
    $sql .= " WHERE order_id LIKE '%$returnSearch%' OR product_name LIKE '%$returnSearch%' OR customer_name LIKE '%$returnSearch%'";
}
$returnResult = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warranty Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 20px; }
        .card { background-color: #ffffff; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .card-header {color: black; border-radius: 10px 10px 0 0; }
        th { background-color: #00408e; color: white; }
        .btn-secondary { background-color: #00408e; border-color: #00408e; }
    </style>
</head>
<body>
<div class="container">

    <!-- Back to Home Button -->
    <div class="mb-3">
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
</div>


    <!-- Warranty Lookup Section -->
    <div class="card">
        <div class="card-header">
            <h3>Warranty Lookup</h3>
        </div>
        <div class="card-body">
            <form method="GET" action="warranty.php">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search by Order ID..." name="searchOrderID" value="<?php echo htmlspecialchars($searchOrderID); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-secondary" type="submit">Search</button>
                    </div>
                </div>
            </form>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Customer Name</th>
                        <th>Purchase Date</th>
                        <th>Warranty End Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($warrantyData as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['order_id']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['billing_time']); ?></td>
                            <td><?php echo htmlspecialchars($item['warranty_end_date']); ?></td>
                            <td>
                                <button class="btn btn-primary" onclick="returnItem('<?php echo htmlspecialchars($item['order_id']); ?>', '<?php echo htmlspecialchars($item['product_name']); ?>', '<?php echo htmlspecialchars($item['customer_name']); ?>', '<?php echo htmlspecialchars($item['warranty_end_date']); ?>')">Return</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Warranty Returns Section -->
    <div class="card mt-4">
        <div class="card-header">
            <h3>Warranty Returns</h3>
        </div>
        <div class="card-body">
            <form method="GET" action="warranty.php">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search returns by Order ID or Customer Name..." name="returnSearch" value="<?php echo htmlspecialchars($returnSearch); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-secondary" type="submit">Search</button>
                    </div>
                </div>
            </form>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Customer Name</th>
                        <th>Return Date</th>
                        <th>Warranty End Date</th>
                        <th>Comments</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($res = mysqli_fetch_array($returnResult)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($res['order_id']); ?></td>
                            <td><?php echo htmlspecialchars($res['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($res['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($res['return_date']); ?></td>
                            <td><?php echo htmlspecialchars($res['warranty_end_date']); ?></td>
                            <td><?php echo htmlspecialchars($res['comments']); ?></td>
                            <td>
                                <?php if (!$res['is_handed_over']): ?>
                                    <form method="POST" action="warranty.php" style="display:inline;">
                                        <input type="hidden" name="action" value="hand_over">
                                        <input type="hidden" name="returnID" value="<?php echo htmlspecialchars($res['return_id']); ?>">
                                        <button type="submit" class="btn btn-warning">Hand Over</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-success">Handed Over</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Toggle Button for Handed Over to Supplier Section -->
    <div class="mt-4">
        <button class="btn btn-primary" onclick="toggleHandedOverSection()">View Handed Over to Supplier</button>
    </div>

    <!-- Handed Over to Supplier Section (Initially Hidden) -->
    <div class="card mt-4" id="handedOverSection" style="display: none;">
        <div class="card-header">
            <h3>Handed Over to Supplier</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Customer Name</th>
                        <th>Return Date</th>
                        <th>Warranty End Date</th>
                        <th>Comments</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $handedOverResult = mysqli_query($conn, "SELECT * FROM warranty_returns WHERE is_handed_over = TRUE");
                    while ($row = mysqli_fetch_array($handedOverResult)) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row['order_id']) . "</td>
                                <td>" . htmlspecialchars($row['product_name']) . "</td>
                                <td>" . htmlspecialchars($row['customer_name']) . "</td>
                                <td>" . htmlspecialchars($row['return_date']) . "</td>
                                <td>" . htmlspecialchars($row['warranty_end_date']) . "</td>
                                <td>" . htmlspecialchars($row['comments']) . "</td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Handle warranty return submission
function returnItem(orderID, productName, customerName, warrantyEndDate) {
    const comments = prompt("Enter any comments regarding the return:");
    if (comments !== null) {
        const form = document.createElement('form');
        form.method = "POST";
        form.action = "warranty.php";

        const inputs = [
            { name: 'action', value: 'return' },
            { name: 'orderID', value: orderID },
            { name: 'productName', value: productName },
            { name: 'customerName', value: customerName },
            { name: 'warrantyEndDate', value: warrantyEndDate },
            { name: 'comments', value: comments }
        ];

        inputs.forEach(inputData => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = inputData.name;
            input.value = inputData.value;
            form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
    }
}

// Toggle visibility of Handed Over to Supplier section
function toggleHandedOverSection() {
    const handedOverSection = document.getElementById("handedOverSection");
    handedOverSection.style.display = handedOverSection.style.display === "none" ? "block" : "none";
}
</script>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
