<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Corrected file paths for PHPMailer
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

// Generate CSRF token
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";
include 'header.php'; // Include the header

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add, delete, or edit product logic
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['token']) {
        die("CSRF token validation failed.");
    }

    if ($_POST['action'] == 'add') {
        $category = $_POST['category'];
        $product_name = $_POST['product_name'];
        $stmt = $conn->prepare("INSERT INTO products (category, product_name) VALUES (?, ?)");
        $stmt->bind_param("ss", $category, $product_name);
        $stmt->execute();
        $stmt->close();
    } elseif ($_POST['action'] == 'delete') {
        $product_id = $_POST['product_id'];
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->close();
    } elseif ($_POST['action'] == 'edit') {
        $product_id = $_POST['product_id'];
        $category = $_POST['category'];
        $product_name = $_POST['product_name'];
        $stmt = $conn->prepare("UPDATE products SET category = ?, product_name = ? WHERE id = ?");
        $stmt->bind_param("ssi", $category, $product_name, $product_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Add, delete, or edit stock logic
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['token']) {
        die("CSRF token validation failed.");
    }

    if ($_POST['action'] == 'edit_stock') {
        $stock_id = $_POST['stock_id'];
        $item_name = $_POST['item_name'];
        $quantity = $_POST['quantity'];
        $received_date = $_POST['received_date'];
        $supplier = $_POST['supplier'];
        $serial_number = $_POST['serial_number'];
        $model = $_POST['model'];
        $warranty = $_POST['warranty'];

        $stmt = $conn->prepare("UPDATE stock SET item_name = ?, quantity = ?, received_date = ?, supplier = ?, 
        serial_number = ?, model = ?, warranty = ? WHERE id = ?");
        $stmt->bind_param("sisssssi", $item_name, $quantity, $received_date, $supplier, 
        $serial_number, $model, $warranty, $stock_id);
        $stmt->execute();
        $stmt->close();
        
        // Check stock quantity and send email if below threshold
        if ($quantity < 2) {
            sendLowStockEmail($item_name, $quantity, $received_date, $supplier, $serial_number, $model, $warranty);
        }
    } elseif ($_POST['action'] == 'delete_stock') {
        $stock_id = $_POST['stock_id'];
        $stmt = $conn->prepare("DELETE FROM stock WHERE id = ?");
        $stmt->bind_param("i", $stock_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Pagination variables for products
$limit = 10; // Number of products per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit; // Calculate the starting row for the query

// Fetch products with pagination and order by id in descending order
$products = [];
$result = $conn->query("SELECT * FROM products ORDER BY id DESC LIMIT $limit OFFSET $offset");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Total number of products for pagination
$totalProductsResult = $conn->query("SELECT COUNT(*) as total FROM products");
$totalProducts = $totalProductsResult->fetch_assoc()['total'];
$totalPages = ceil($totalProducts / $limit);

// Pagination variables for stock management
$stockLimit = 10; // Number of stock items per page
$stockPage = isset($_GET['stock_page']) ? (int)$_GET['stock_page'] : 1;
$stockOffset = ($stockPage - 1) * $stockLimit;

// Fetch stock items
$stockItems = [];
$stockResult = $conn->query("SELECT * FROM stock ORDER BY id DESC LIMIT $stockLimit OFFSET $stockOffset");

if ($stockResult->num_rows > 0) {
    while ($row = $stockResult->fetch_assoc()) {
        $stockItems[] = $row;
    }
}

// Total number of stock items for pagination
$totalStockResult = $conn->query("SELECT COUNT(*) as total FROM stock");
$totalStock = $totalStockResult->fetch_assoc()['total'];
$totalStockPages = ceil($totalStock / $stockLimit);

// Fetch customer returns where supplier is empty
$customerReturns = [];
$returnsResult = $conn->query("SELECT * FROM stock WHERE supplier IS NULL OR supplier = ''");
if ($returnsResult->num_rows > 0) {
    while ($row = $returnsResult->fetch_assoc()) {
        $customerReturns[] = $row;
    }
}

// Export logic for both products and stock
if (isset($_POST['export'])) {
    $format = $_POST['format'];
    $table = $_POST['table'];
    $columns = isset($_POST['columns']) ? $_POST['columns'] : [];

    if (empty($columns)) {
        die("No columns selected for export.");
    }

    $selectedColumns = implode(',', $columns);
    $filename = "{$table}_" . date('Ymd') . ".{$format}";
    $output = fopen($filename, 'w');

    // Fetch selected columns for the selected table
    $tableResult = $conn->query("SELECT {$selectedColumns} FROM {$table}");

    if ($format == 'csv') {
        fputcsv($output, $columns);
        while ($row = $tableResult->fetch_assoc()) {
            fputcsv($output, array_intersect_key($row, array_flip($columns)));
        }
    } elseif ($format == 'txt') {
        fwrite($output, implode("\t", $columns) . "\n");
        while ($row = $tableResult->fetch_assoc()) {
            fwrite($output, implode("\t", array_intersect_key($row, array_flip($columns))) . "\n");
        }
    } elseif ($format == 'pdf') {
        // PDF export with styling (using FPDF library)
        require('fpdf/fpdf.php');
        $pdf = new FPDF();
        $pdf->AddPage();

        // Set the font and colors for the header
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetFillColor(100, 149, 237); // Set background color for header
        $pdf->SetTextColor(255, 255, 255); // Set text color for header

        // Header row with background color
        foreach ($columns as $column) {
            $pdf->Cell(40, 10, $column, 1, 0, 'C', true); // true for background fill
        }
        $pdf->Ln(); // Line break

        // Set font for table content
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetTextColor(0, 0, 0); // Set text color for content

        // Table data
        while ($row = $tableResult->fetch_assoc()) {
            foreach (array_intersect_key($row, array_flip($columns)) as $data) {
                $pdf->Cell(40, 10, $data, 1); // Default no background for content
            }
            $pdf->Ln();
        }

        // Output the PDF
        $pdf->Output('F', $filename);
    }

    fclose($output);

    // Force download
    header("Content-Type: application/{$format}");
    header("Content-Disposition: attachment; filename=" . $filename);
    readfile($filename);

    // Remove the file after download
    unlink($filename);
    exit;
}

// Function to send low stock email using PHPMailer
function sendLowStockEmail($item_name, $quantity, $received_date, $supplier, $serial_number, $model, $warranty) {
    $mail = new PHPMailer(true);

    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'Raazimramzaan123@gmail.com'; // Your Gmail email address
        $mail->Password = 'jpty jsgr ntzt hhor';  // Your Gmail app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
        $mail->Port = 587;  // TCP port for TLS
        
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'Smart Touch'); // Set sender
        $mail->addAddress('Raazimramzaan123@gmail.com'); // Add a recipient

        // Email content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = 'Low Stock Alert for ' . $item_name;
        $mail->Body    = "The following item is low in stock:<br><br>" .
                         "Item Name: $item_name<br>" .
                         "Quantity: $quantity<br>" .
                         "Received Date: $received_date<br>" .
                         "Supplier: $supplier<br>" .
                         "Serial Number: $serial_number<br>" .
                         "Model: $model<br>" .
                         "Warranty: $warranty<br>";

        // Send email
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock & Product Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 20px;
        }
        .nav-tabs {
            margin-bottom: 20px;
        }
        .tab-content {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
        }
        .low-stock-overall {
            background-color: #f8d7da;
            color: #721c24;
        }
        table {
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 10px;
        }
        th {
            background-color: #00408e;
            color: white;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        #edit-product-form {
            display: none;
            margin-top: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        #overall-stock-table, #customer-returns-table {
            margin-top: 20px;
            display: none;
        }
    </style>
</head>
<body>

<div class="container">
<div class="container">
    <!-- Back to Home Button -->
    <div class="mb-3">
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
</div>


    <h2>Stock & Product Management</h2>
    <ul class="nav nav-tabs" id="managementTabs">
        <li class="nav-item">
            <a class="nav-link active" href="#" onclick="showTab('productManagement')">Product Management</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" onclick="showTab('stockManagement')">Stock Management</a>
        </li>
    </ul>

    <div class="tab-content">
        <!-- Product Management Content -->
        <div id="productManagement" class="tab-pane active">
            <h3>Manage Products</h3>
            <form id="product-form" method="POST">
                <input type="hidden" id="product_id" name="product_id">
                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" class="form-control" required>
                        <option value="" disabled selected>Select Category</option>
                        <option value="Laptop">Laptop</option>
                        <option value="Keyboard">Keyboard</option>
                        <option value="Mouse">Mouse</option>
                        <option value="PC">PC</option>
                        <option value="Headset">Headset</option>
                        <option value="CPU">CPU</option>
                        <option value="Motherboard">Motherboard</option>
                        <option value="Monitor">Monitor</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="product_name">Product Name</label>
                    <input type="text" id="product_name" name="product_name" class="form-control" required>
                </div>
                <button type="submit" name="action" value="add" class="btn btn-primary">Save Product</button>
            </form>

            <!-- Edit Product Form -->
            <div id="edit-product-form">
                <h4>Edit Product</h4>
                <form method="POST">
                    <input type="hidden" id="edit_product_id" name="product_id">
                    <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                    <div class="form-group">
                        <label for="edit_category">Category</label>
                        <select id="edit_category" name="category" class="form-control" required>
                            <option value="" disabled>Select Category</option>
                            <option value="Laptop">Laptop</option>
                            <option value="Keyboard">Keyboard</option>
                            <option value="Mouse">Mouse</option>
                            <option value="PC">PC</option>
                            <option value="Headset">Headset</option>
                            <option value="CPU">CPU</option>
                            <option value="Motherboard">Motherboard</option>
                            <option value="Monitor">Monitor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_product_name">Product Name</label>
                        <input type="text" id="edit_product_name" name="product_name" class="form-control" required>
                    </div>
                    <button type="submit" name="action" value="edit" class="btn btn-primary">Update Product</button>
                    <button type="button" class="btn btn-secondary" onclick="hideEditForm('product')">Cancel</button>
                </form>
            </div>

            <h3>Products List</h3>
            <input type="text" id="search-input" class="form-control" placeholder="Search for products..." onkeyup="searchProducts()">
            <table class="table table-bordered" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Product Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="products-list">
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                        <td class="action-buttons">
                            <button class="btn btn-primary" onclick="toggleEditForm('product', '<?php echo htmlspecialchars($product['category']); ?>', '<?php echo htmlspecialchars($product['product_name']); ?>', <?php echo $product['id']; ?>)">Edit</button>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                                <button type="submit" name="action" value="delete" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination links -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Export Products button -->
            <form method="POST" action="">
                <div class="form-group">
                    <label for="format">Select Format</label>
                    <select id="format" name="format" class="form-control" required>
                        <option value="csv">CSV</option>
                        <option value="txt">Text</option>
                        <option value="pdf">PDF</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="columns">Select Columns to Export</label>
                    <select id="columns" name="columns[]" class="form-control" multiple required>
                        <option value="id">ID</option>
                        <option value="category">Category</option>
                        <option value="product_name">Product Name</option>
                    </select>
                </div>
                <input type="hidden" name="table" value="products">
                <button type="submit" name="export" class="btn btn-success">Export Products</button>
            </form>
        </div>

        <!-- Stock Management Content -->
        <div id="stockManagement" class="tab-pane">
            <h3>Stock Management</h3>
            <form id="edit-stock-form" method="POST" style="display:none;">
                <input type="hidden" id="stock_id" name="stock_id">
                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                <div class="form-group">
                    <label for="item_name">Item Name</label>
                    <input type="text" id="item_name" name="item_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" id="quantity" name="quantity" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="received_date">Received Date</label>
                    <input type="date" id="received_date" name="received_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="supplier">Supplier</label>
                    <input type="text" id="supplier" name="supplier" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="serial_number">Serial Number</label>
                    <input type="text" id="serial_number" name="serial_number" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="model">Model</label>
                    <input type="text" id="model" name="model" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="warranty">Warranty</label>
                    <input type="text" id="warranty" name="warranty" class="form-control" required>
                </div>
                <button type="submit" name="action" value="edit_stock" class="btn btn-primary">Update Stock</button>
            </form>

            <input type="text" id="search-stock-input" class="form-control" placeholder="Search for stock items..." onkeyup="searchStock()">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Ordered Date</th>
                        <th>Order ID</th>
                        <th>Supplier</th>
                        <th>Quantity</th>
                        <th>Warranty</th>
                        <th>Serial Number</th>
                        <th>Model</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="stock-items-list">
                    <?php foreach ($stockItems as $stockItem): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($stockItem['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($stockItem['received_date']); ?></td>
                        <td><?php echo htmlspecialchars($stockItem['order_number']); ?></td>
                        <td><?php echo htmlspecialchars($stockItem['supplier']); ?></td>
                        <td><?php echo htmlspecialchars($stockItem['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($stockItem['warranty']); ?></td>
                        <td>
                            <?php 
                            $serials = explode(',', $stockItem['serial_number']);
                            foreach ($serials as $serial) {
                                echo "<span class='serial-box'>" . htmlspecialchars($serial) . "</span><br>";
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            $models = explode(',', $stockItem['model']);
                            foreach ($models as $model) {
                                echo "<span class='model-box'>" . htmlspecialchars($model) . "</span><br>";
                            }
                            ?>
                        </td>
                        <td class="action-buttons">
                            <button class="btn btn-primary" onclick="toggleEditForm('stock', '<?php echo htmlspecialchars($stockItem['item_name']); ?>', '<?php echo htmlspecialchars($stockItem['quantity']); ?>', '<?php echo htmlspecialchars($stockItem['received_date']); ?>', '<?php echo htmlspecialchars($stockItem['supplier']); ?>', '<?php echo htmlspecialchars($stockItem['serial_number']); ?>', '<?php echo htmlspecialchars($stockItem['model']); ?>', '<?php echo htmlspecialchars($stockItem['warranty']); ?>', <?php echo $stockItem['id']; ?>)">Edit</button>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="stock_id" value="<?php echo $stockItem['id']; ?>">
                                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                                <button type="submit" name="action" value="delete_stock" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <button class="btn btn-warning" id="low-stock-btn" onclick="toggleStockView()">Low Stocks</button>
<!-- Re-Order button -->
<a href="ReOrder.php" class="btn btn-secondary" id="reorder-btn">Re-Order</a>

            <!-- Overall Stock button -->
            <button class="btn btn-info" id="overall-stock-btn" onclick="toggleOverallStock()">Overall Stock Count</button>
            <table class="table table-bordered" id="overall-stock-table">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Available Quantity</th>
                    </tr>
                </thead>
                <tbody id="overall-stock-list">
                    <!-- Data will be dynamically generated here -->
                </tbody>
            </table>

            <!-- Customer Returns button -->
            <button class="btn btn-success" id="customer-returns-btn" onclick="toggleCustomerReturns()">Customer Returns</button>
            <table class="table table-bordered" id="customer-returns-table">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Received Date</th>
                        <th>Serial Number</th>
                        <th>Model</th>
                        <th>Warranty</th>
                    </tr>
                </thead>
                <tbody id="customer-returns-list">
                    <!-- Data will be dynamically generated here -->
                </tbody>
            </table>

            <!-- Pagination links for stock -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php if ($stockPage > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?stock_page=<?php echo $stockPage - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalStockPages; $i++): ?>
                        <li class="page-item <?php if ($i == $stockPage) echo 'active'; ?>">
                            <a class="page-link" href="?stock_page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($stockPage < $totalStockPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?stock_page=<?php echo $stockPage + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Export Stock button -->
            <form method="POST" action="">
                <div class="form-group">
                    <label for="format">Select Format</label>
                    <select id="format" name="format" class="form-control" required>
                        <option value="csv">CSV</option>
                        <option value="txt">Text</option>
                        <option value="pdf">PDF</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="columns">Select Columns to Export</label>
                    <select id="columns" name="columns[]" class="form-control" multiple required>
                        <option value="id">ID</option>
                        <option value="item_name">Item Name</option>
                        <option value="quantity">Quantity</option>
                        <option value="received_date">Received Date</option>
                        <option value="supplier">Supplier</option>
                        <option value="serial_number">Serial Number</option>
                        <option value="model">Model</option>
                        <option value="warranty">Warranty</option>
                    </select>
                </div>
                <input type="hidden" name="table" value="stock">
                <button type="submit" name="export" class="btn btn-success">Export Stock</button>
            </form>
        </div>
    </div>
</div>

<script>
    function showTab(tabId) {
        const tabs = document.querySelectorAll('.tab-pane');
        tabs.forEach(tab => tab.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
    }

    function toggleEditForm(type, ...data) {
        const form = document.getElementById(`edit-${type}-form`);
        if (form.style.display === "none" || form.style.display === "") {
            if (type === 'product') {
                document.getElementById('edit_category').value = data[0];
                document.getElementById('edit_product_name').value = data[1];
                document.getElementById('edit_product_id').value = data[2];
            } else {
                document.getElementById('stock_id').value = data[7];
                document.getElementById('item_name').value = data[0];
                document.getElementById('quantity').value = data[1];
                document.getElementById('received_date').value = data[2];
                document.getElementById('supplier').value = data[3];
                document.getElementById('serial_number').value = data[4];
                document.getElementById('model').value = data[5];
                document.getElementById('warranty').value = data[6];
            }
            form.style.display = "block";
        } else {
            form.style.display = "none";
        }
    }

    function hideEditForm(type) {
        const form = document.getElementById(`edit-${type}-form`);
        form.style.display = "none";
    }

    function searchProducts() {
        const input = document.getElementById('search-input').value.toLowerCase();
        const rows = document.querySelectorAll('#products-list tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(input));
            row.style.display = matches ? '' : 'none';
        });
    }

    function searchStock() {
        const input = document.getElementById('search-stock-input').value.toLowerCase();
        const rows = document.querySelectorAll('#stock-items-list tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(input));
            row.style.display = matches ? '' : 'none';
        });
    }

    let showingLowStocks = false; // Track whether low stock is being shown

    function toggleStockView() {
    const rows = document.querySelectorAll('#stock-items-list tr');
    const lowStockBtn = document.getElementById('low-stock-btn');

    if (showingLowStocks) {
        // Show all stocks (reset the table)
        rows.forEach(row => {
            row.style.display = ''; // Show all rows
        });
        lowStockBtn.textContent = 'Low Stocks'; // Change button text to "Low Stocks"
        showingLowStocks = false;
    } else {
        // Show only low stocks
        rows.forEach(row => {
            const quantityCell = row.querySelector('td:nth-child(5)'); // Assuming quantity is the 5th column
            const quantity = parseInt(quantityCell.textContent.trim(), 10);
            
            if (quantity !== 0) {
                row.style.display = 'none'; // Hide items with quantity > 0
            } else {
                row.style.display = ''; // Show items with quantity == 0 (low stock)
            }
        });
        lowStockBtn.textContent = 'Show All Stocks'; // Change button text to "Show All Stocks"
        showingLowStocks = true;
    }
}

    function toggleOverallStock() {
        const stockTable = document.getElementById('overall-stock-table');
        if (stockTable.style.display === 'none' || stockTable.style.display === '') {
            showOverallStock(); // Show the stock table and populate
            stockTable.style.display = 'table';
        } else {
            stockTable.style.display = 'none'; // Hide the stock table
        }
    }

    function showOverallStock() {
        const stockItems = <?php echo json_encode($stockItems); ?>; // PHP to JavaScript array
        const stockTableBody = document.getElementById('overall-stock-list');
        stockTableBody.innerHTML = ''; // Clear the existing table data

        const stockSummary = {};

        // Loop through stock items and summarize the quantities
        stockItems.forEach(item => {
            if (stockSummary[item.item_name]) {
                stockSummary[item.item_name] += parseInt(item.quantity);
            } else {
                stockSummary[item.item_name] = parseInt(item.quantity);
            }
        });

        // Populate the overall stock table
        for (const itemName in stockSummary) {
            const row = document.createElement('tr');
            const itemCell = document.createElement('td');
            const quantityCell = document.createElement('td');

            itemCell.textContent = itemName;
            quantityCell.textContent = stockSummary[itemName];

            // Apply red effect for low stock (quantity < 2)
            if (stockSummary[itemName] < 2) {
                row.classList.add('low-stock-overall');
            }

            row.appendChild(itemCell);
            row.appendChild(quantityCell);

            stockTableBody.appendChild(row);
        }

        // Show the overall stock table
        document.getElementById('overall-stock-table').style.display = 'table';
    }

    function toggleCustomerReturns() {
        const returnsTable = document.getElementById('customer-returns-table');
        if (returnsTable.style.display === 'none' || returnsTable.style.display === '') {
            showCustomerReturns(); // Show the customer returns table and populate
            returnsTable.style.display = 'table';
        } else {
            returnsTable.style.display = 'none'; // Hide the customer returns table
        }
    }

    function showCustomerReturns() {
        const customerReturns = <?php echo json_encode($customerReturns); ?>; // PHP to JavaScript array
        const returnsTableBody = document.getElementById('customer-returns-list');
        returnsTableBody.innerHTML = ''; // Clear the existing table data

        // Populate the customer returns table
        customerReturns.forEach(returnItem => {
            const row = document.createElement('tr');
            const itemCell = document.createElement('td');
            const quantityCell = document.createElement('td');
            const receivedDateCell = document.createElement('td');
            const serialCell = document.createElement('td');
            const modelCell = document.createElement('td');
            const warrantyCell = document.createElement('td');

            itemCell.textContent = returnItem.item_name;
            quantityCell.textContent = returnItem.quantity;
            receivedDateCell.textContent = returnItem.received_date;
            serialCell.textContent = returnItem.serial_number;
            modelCell.textContent = returnItem.model;
            warrantyCell.textContent = returnItem.warranty;

            row.appendChild(itemCell);
            row.appendChild(quantityCell);
            row.appendChild(receivedDateCell);
            row.appendChild(serialCell);
            row.appendChild(modelCell);
            row.appendChild(warrantyCell);

            returnsTableBody.appendChild(row);
        });

        // Show the customer returns table
        document.getElementById('customer-returns-table').style.display = 'table';
    }
</script>

</body>
</html>
