<?php
session_start();
include_once("header.php");

// Generate CSRF token for security
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['token']) {
        die("CSRF token validation failed.");
    }

    $action = $_POST['action'];

    if ($action === 'insert_return') {
        $order_id = $_POST['order_id'];
        $return_date = $_POST['return_date'];
        $return_reason = $_POST['return_reason'];
    
        // Fetch details from billed_items table
        $stmt = $conn->prepare("
            SELECT order_number, customer_name, product_name, quantity, serial_number, model, warranty 
            FROM billed_items 
            WHERE order_id = ? 
            LIMIT 1
        ");
        $stmt->bind_param("s", $order_id);
        $stmt->execute();
        $stmt->bind_result($order_number, $customer_name, $item_name, $quantity, $serial_number, $model, $warranty);
        $stmt->fetch();
        $stmt->close();

        if (empty($order_number)) {
            die("No matching order found for this Order ID.");
        }

        // Insert details into customer_return table
        $stmt = $conn->prepare("
            INSERT INTO customer_return (order_id, customer_name, item_name, 
            quantity, serial_number, model, warranty, return_date, return_reason, checked_status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Unchecked', NOW())
        ");
        $stmt->bind_param("sssisssss", $order_id, $customer_name, $item_name, 
        $quantity, $serial_number, $model, $warranty, $return_date, $return_reason);

        if ($stmt->execute()) {
            // Redirect to reload the page
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            die("Failed to insert return.");
        }
    
        
        
    } elseif ($action === 'check_return') {
        $return_id = $_POST['return_id'];

        // Update the record to "Checked"
        $stmt = $conn->prepare("UPDATE customer_return SET checked_status = 'Checked' WHERE id = ?");
        $stmt->bind_param("i", $return_id);

        if ($stmt->execute()) {
            // Redirect to warranty.php after marking as checked
            header("Location: warranty.php?return_id={$return_id}&token={$_SESSION['token']}");
            exit;
        } else {
            echo json_encode(["success" => false, "message" => "Failed to mark return as checked."]);
        }
        $stmt->close();
        exit;
    } elseif ($action === 'delete_return') {
        $return_id = $_POST['return_id'];

        // Delete the record
        $stmt = $conn->prepare("DELETE FROM customer_return WHERE id = ?");
        $stmt->bind_param("i", $return_id);
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Return record deleted successfully."]);
        } else {
            echo json_encode(["success" => false, "message" => "Failed to delete return record."]);
        }
        $stmt->close();
        exit;
    }
}

// Fetch billed items for the dropdown
$billedItems = [];
$billedResult = $conn->query("SELECT order_id FROM billed_items");
if ($billedResult->num_rows > 0) {
    while ($row = $billedResult->fetch_assoc()) {
        $billedItems[] = $row;
    }
}

// Fetch customer returns
$customerReturns = [];
$customerResult = $conn->query("SELECT * FROM customer_return ORDER BY id DESC");
if ($customerResult->num_rows > 0) {
    while ($row = $customerResult->fetch_assoc()) {
        $customerReturns[] = $row;
    }
}

// Define pagination variables
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page, defaults to 1
$offset = ($page - 1) * $limit; // Calculate the starting record

$supplierReturns = [];
$supplierResult = $conn->query("SELECT * FROM supplier_return ORDER BY id DESC LIMIT $limit OFFSET $offset");
if ($supplierResult->num_rows > 0) {
    while ($row = $supplierResult->fetch_assoc()) {
        $supplierReturns[] = $row;
    }
}

// Count total returns for pagination
$totalCustomerReturns = $conn->query("SELECT COUNT(*) as total FROM customer_return")->fetch_assoc()['total'];
$totalPagesCustomer = ceil($totalCustomerReturns / $limit);

$totalSupplierReturns = $conn->query("SELECT COUNT(*) as total FROM supplier_return")->fetch_assoc()['total'];
$totalPagesSupplier = ceil($totalSupplierReturns / $limit);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'export_supplier') {
        $format = $_POST['format']; // Format: csv, txt, or pdf
        $columns = isset($_POST['columns']) ? $_POST['columns'] : []; // Selected columns
        $table = 'supplier_return'; // Table for supplier returns

        if (empty($columns)) {
            die("No columns selected for export.");
        }

        $selectedColumns = implode(',', $columns); // Prepare selected columns for SQL
        $filename = "supplier_returns_" . date('Ymd') . ".{$format}"; // Filename based on format and date

        // Fetch data for export
        $query = "SELECT {$selectedColumns} FROM {$table}";
        $exportResult = $conn->query($query);

        if (!$exportResult) {
            die("Error fetching data: " . $conn->error);
        }

        // Export in CSV format
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header("Content-Disposition: attachment; filename={$filename}");
            $output = fopen('php://output', 'w');
            fputcsv($output, $columns); // Add header row
            while ($row = $exportResult->fetch_assoc()) {
                fputcsv($output, array_intersect_key($row, array_flip($columns))); // Add data rows
            }
            fclose($output);
            exit;
        }

        // Export in TXT format
        elseif ($format === 'txt') {
            header('Content-Type: text/plain');
            header("Content-Disposition: attachment; filename={$filename}");
            echo implode("\t", $columns) . "\n"; // Add header row
            while ($row = $exportResult->fetch_assoc()) {
                echo implode("\t", array_intersect_key($row, array_flip($columns))) . "\n"; // Add data rows
            }
            exit;
        }

        // Export in PDF format
        elseif ($format === 'pdf') {
            require('fpdf/fpdf.php');
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 12);

            // Add Title
            $pdf->Cell(190, 10, 'Supplier Returns Export', 0, 1, 'C');
            $pdf->Ln(10);

            // Add column headers
            foreach ($columns as $column) {
                $pdf->Cell(40, 10, ucfirst(str_replace('_', ' ', $column)), 1, 0, 'C');
            }
            $pdf->Ln();

            // Add row data
            while ($row = $exportResult->fetch_assoc()) {
                foreach (array_intersect_key($row, array_flip($columns)) as $data) {
                    $pdf->Cell(40, 10, $data, 1, 0, 'C');
                }
                $pdf->Ln();
            }

            // Output PDF
            header('Content-Type: application/pdf');
            header("Content-Disposition: attachment; filename={$filename}");
            $pdf->Output('D');
            exit;
        }
    }
}

// Fetch order details via AJAX
if (isset($_GET['order_id'])) {
    header('Content-Type: application/json');
    $order_id = $_GET['order_id'];
    $stmt = $conn->prepare("
        SELECT customer_name, product_name, quantity, serial_number, model, warranty 
        FROM billed_items 
        WHERE order_id = ?
    ");
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->bind_result($customer_name, $product_name, $quantity, $serial_number, $model, $warranty);
    $stmt->fetch();
    $stmt->close();

    echo json_encode([
        "customer_name" => $customer_name,
        "product_name" => $product_name,
        "quantity" => $quantity,
        "serial_number" => $serial_number,
        "model" => $model,
        "warranty" => $warranty
    ]);
    exit;
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .nav-tabs {
            margin-bottom: 20px;
        }
        table {
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 10px;
        }
        th {
            background-color: #00408e;
            color: white;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        #edit-form {
            margin-bottom: 20px;
            display: none; /* Initially hide the form */
        }
        #clear-search-btn, #clear-customer-search-btn {
            margin-top: 10px;
            display: none; /* Initially hide the button */
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Return Management</h2>

    <div class="container">
    <!-- Back to Home Button -->
    <div class="mb-3">
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
    </div>

    <ul class="nav nav-tabs" id="returnTabs">
    <li class="nav-item">
        <a class="nav-link" href="#" onclick="showTab('supplierReturn')">Supplier Return</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#" onclick="showTab('customerReturn')">Customer Return</a>
    </li>
</ul>

    <div class="tab-content">
        <!-- Supplier Return Management -->
        <div id="supplierReturn" class="tab-pane active">
            <!-- Edit Form -->
            <div id="edit-form">
                <h3>Edit Return</h3>
                <form method="POST">
                    <input type="hidden" id="edit-return-id" name="return_id">
                    <input type="hidden" id="edit-return-type" name="return_type">
                    <div class="form-group">
                        <label for="edit-order-number">Order Number</label>
                        <input type="text" id="edit-order-number" name="order_number" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="edit-item-name">Item Name</label>
                        <input type="text" id="edit-item-name" name="item_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-quantity">Quantity</label>
                        <input type="number" id="edit-quantity" name="quantity" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-serial-number">Serial Number</label>
                        <input type="text" id="edit-serial-number" name="serial_number" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-model">Model</label>
                        <input type="text" id="edit-model" name="model" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-warranty">Warranty</label>
                        <input type="text" id="edit-warranty" name="warranty" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-return-date">Return Date</label>
                        <input type="date" id="edit-return-date" name="return_date" class="form-control" required>
                    </div>
                    <button type="submit" name="action" value="edit_return" class="btn btn-primary">Save Changes</button>
                </form>
            </div>

            <!-- Search bar and Clear Search Button for Supplier Return-->
            <input type="text" id="search-input" class="form-control" placeholder="Search for returns..." onkeyup="searchReturns()">
            <button id="clear-search-btn" class="btn btn-secondary" onclick="clearSearch()">Clear Search</button>

            <!-- Supplier Return List -->
            <table class="table table-bordered" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th>Order Number</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Serial Number</th>
                        <th>Model</th>
                        <th>Warranty</th>
                        <th>Return Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="returns-list">
                    <?php foreach ($supplierReturns as $return): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($return['order_number']); ?></td>
                        <td><?php echo htmlspecialchars($return['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($return['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($return['serial_number']); ?></td>
                        <td><?php echo htmlspecialchars($return['model']); ?></td>
                        <td><?php echo htmlspecialchars($return['warranty']); ?></td>
                        <td><?php echo htmlspecialchars($return['return_date']); ?></td>
                        <td class="action-buttons">
                            <button class="btn btn-primary" onclick="fillEditForm(<?php echo $return['id']; ?>, '<?php echo htmlspecialchars($return['order_number']); ?>', '<?php echo htmlspecialchars($return['item_name']); ?>', <?php echo $return['quantity']; ?>, '<?php echo htmlspecialchars($return['serial_number']); ?>', '<?php echo htmlspecialchars($return['model']); ?>', '<?php echo htmlspecialchars($return['warranty']); ?>', '<?php echo htmlspecialchars($return['return_date']); ?>', 'supplier')">Edit</button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="return_id" value="<?php echo $return['id']; ?>">
                                <input type="hidden" name="return_type" value="supplier">
                                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                                <button type="submit" name="action" value="delete_return" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination links for Supplier Return -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPagesSupplier; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPagesSupplier): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <form method="POST" action="return.php">
    <div class="form-group">
        <label for="format">Select Format</label>
        <select id="format" name="format" class="form-control" required>
            <option value="csv">CSV</option>
            <option value="txt">Text</option>
            <option value="pdf">PDF</option>
        </select>
    </div>
    <div class="form-group">
        <label for="columns">Select Columns to Export</label>
        <select id="columns" name="columns[]" class="form-control" multiple required>
            <option value="id">ID</option>
            <option value="order_number">Order Number</option>
            <option value="item_name">Item Name</option>
            <option value="quantity">Quantity</option>
            <option value="serial_number">Serial Number</option>
            <option value="model">Model</option>
            <option value="warranty">Warranty</option>
            <option value="return_date">Return Date</option>
        </select>
    </div>
    <!-- Add CSRF Token -->
    <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
    <input type="hidden" name="return_type" value="supplier">
    <input type="hidden" name="action" value="export_supplier">
    <button type="submit" class="btn btn-success">Export Returns</button>
</form>

        </div>

        <div id="customerReturn" class="tab-pane">
    <h3>Insert Customer Return</h3>
    <!-- Insert Form for Customer Return -->
    <form method="POST" action="">
    <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
    <input type="hidden" name="action" value="insert_return">
    
    <div class="form-group">
        <label for="order-id">Select Order ID</label>
        <select id="order-id" name="order_id" class="form-control" required>
            <option value="" disabled selected>Select an order</option>
            <?php foreach ($billedItems as $item): ?>
                <option value="<?php echo $item['order_id']; ?>"><?php echo $item['order_id']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="return-date">Return Date</label>
        <input type="date" id="return-date" name="return_date" class="form-control" required>
    </div>

    <div class="form-group">
        <label for="return-reason">Return Reason</label>
        <select id="return-reason" name="return_reason" class="form-control" required>
            <option value="" disabled selected>Select a reason</option>
            <option value="Defective product">Defective product</option>
            <option value="Wrong item delivered">Wrong item delivered</option>
            <option value="Item no longer needed">Item no longer needed</option>
            <option value="Product not as described">Product not as described</option>
            <option value="Received damaged">Received damaged</option>
            <option value="Quality not satisfactory">Quality not satisfactory</option>
            <option value="Product expired">Product expired</option>
            <option value="Other">Other</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Submit Return</button>
</form>

    <br>

    <!-- Search bar and Clear Search Button for Customer Return -->
    <input type="text" id="customer-search-input" class="form-control" placeholder="Search for returns..." onkeyup="searchCustomerReturns()">
    <button id="clear-customer-search-btn" class="btn btn-secondary" onclick="clearCustomerSearch()">Clear Search</button>

    <!-- Customer Return List -->
    <table class="table table-bordered" style="margin-top: 20px;">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Serial Number</th>
                <th>Model</th>
                <th>Warranty</th>
                <th>Return Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="customer-returns-list">
            <?php foreach ($customerReturns as $return): ?>
            <tr>
                <td><?php echo htmlspecialchars($return['order_id']); ?></td>
                <td><?php echo htmlspecialchars($return['customer_name']); ?></td>
                <td><?php echo htmlspecialchars($return['item_name']); ?></td>
                <td><?php echo htmlspecialchars($return['quantity']); ?></td>
                <td><?php echo htmlspecialchars($return['serial_number']); ?></td>
                <td><?php echo htmlspecialchars($return['model']); ?></td>
                <td><?php echo htmlspecialchars($return['warranty']); ?></td>
                <td><?php echo htmlspecialchars($return['return_date']); ?></td>
                <td class="action-buttons">
    <!-- Check Button -->
    <button 
    class="btn btn-primary check-button"
    data-id="<?php echo $return['id']; ?>"
    <?php echo $return['checked_status'] === 'Checked' ? 'disabled' : ''; ?>>
    <?php echo $return['checked_status'] === 'Checked' ? 'Checked' : 'Check'; ?>
</button>


    <!-- Delete Button -->
    <form method="POST" style="display:inline;">
        <input type="hidden" name="return_id" value="<?php echo $return['id']; ?>">
        <input type="hidden" name="action" value="delete_return">
        <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
        <button type="submit" class="btn btn-danger delete-button">Delete</button>
    </form>
</td>

            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Pagination links for Customer Return -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPagesCustomer; $i++): ?>
                <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $totalPagesCustomer): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- Export Section for Customer Return -->
    <form method="POST" action="">
        <div class="form-group">
            <label for="format">Select Format</label>
            <select id="format" name="format" class="form-control" required>
                <option value="csv">CSV</option>
                <option value="txt">Text</option>
                <option value="pdf">PDF</option>
            </select>
        </div>
        <div class="form-group">
            <label for="columns">Select Columns to Export</label>
            <select id="columns" name="columns[]" class="form-control" multiple required>
                <option value="id">ID</option>
                <option value="order_id">Order ID</option>
                <option value="customer_name">Customer Name</option>
                <option value="item_name">Item Name</option>
                <option value="quantity">Quantity</option>
                <option value="serial_number">Serial Number</option>
                <option value="model">Model</option>
                <option value="warranty">Warranty</option>
                <option value="return_date">Return Date</option>
                <option value="checked_status">Checked Status</option>
            </select>
        </div>
        <input type="hidden" name="return_type" value="customer">
        <button type="submit" name="export" class="btn btn-success">Export Returns</button>
    </form>
</div>

<script>
document.querySelector('form[action=""]').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission behavior

    const form = this; // Reference to the form
    const formData = new FormData(form); // Serialize form data

    fetch('return.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => {
        if (response.ok) {
            window.location.reload(); // Reload the page to reflect the changes
        } else {
            console.error('Error occurred while saving the return.');
        }
    })
    .catch(error => console.error('Error:', error));
});



// Remove this function
function showSuccessMessage(message) {
    const successMessage = document.getElementById('success-message');
    successMessage.textContent = message;
    successMessage.style.display = 'block'; // Show the message

    // Hide the message after 5 seconds
    setTimeout(() => {
        successMessage.style.display = 'none';
    }, 5000);
}

// Function to show the selected tab and store it in localStorage
function showTab(tabId) {
    // Store the active tab in localStorage
    localStorage.setItem('activeTab', tabId);

    // Show the selected tab and hide others
    document.querySelectorAll('.tab-pane').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');

    // Update the navigation link styling
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    document.querySelector(`[onclick="showTab('${tabId}')"]`).classList.add('active');
}

document.querySelectorAll('.check-button').forEach(button => {
    button.addEventListener('click', function () {
        const returnId = this.getAttribute('data-id'); // Get the return ID
        const csrfToken = '<?php echo $_SESSION['token']; ?>'; // Fetch CSRF token

        // Submit a form to trigger the PHP action
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'return.php';

        // Add hidden inputs
        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'check_return';
        form.appendChild(actionInput);

        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'return_id';
        idInput.value = returnId;
        form.appendChild(idInput);

        const tokenInput = document.createElement('input');
        tokenInput.type = 'hidden';
        tokenInput.name = 'token';
        tokenInput.value = csrfToken;
        form.appendChild(tokenInput);

        document.body.appendChild(form);
        form.submit();
    });
});

// Function to handle the delete action
document.querySelectorAll('.delete-button').forEach(button => {
    button.addEventListener('click', function (e) {
        e.preventDefault(); // Prevent default form submission

        const form = this.closest('form'); // Get the associated form
        const formData = new FormData(form); // Serialize the form data

        fetch('return.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => {
            if (response.ok) {
                location.reload(); // Reload the page to reflect the deletion
            } else {
                console.error('Failed to delete the record. Please try again.');
            }
        })
        .catch(error => console.error('Error:', error));
    });
});

// Function to search supplier returns
function searchReturns() {
    const input = document.getElementById('search-input').value.toLowerCase();
    const rows = document.querySelectorAll('#returns-list tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(input));
        row.style.display = matches ? '' : 'none';
    });

    const clearBtn = document.getElementById('clear-search-btn');
    clearBtn.style.display = input ? 'block' : 'none';
}

// Function to search customer returns
function searchCustomerReturns() {
    const input = document.getElementById('customer-search-input').value.toLowerCase();
    const rows = document.querySelectorAll('#customer-returns-list tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(input));
        row.style.display = matches ? '' : 'none';
    });

    const clearBtn = document.getElementById('clear-customer-search-btn');
    clearBtn.style.display = input ? 'block' : 'none';
}

// Function to clear supplier search input
function clearSearch() {
    document.getElementById('search-input').value = '';
    searchReturns();
}

// Function to clear customer search input
function clearCustomerSearch() {
    document.getElementById('customer-search-input').value = '';
    searchCustomerReturns();
}

// Function to pre-fill the edit form
function fillEditForm(id, orderNumber, itemName, quantity, serialNumber, model, warranty, returnDate, type) {
    document.getElementById('edit-return-id').value = id;
    document.getElementById('edit-order-number').value = orderNumber;
    document.getElementById('edit-item-name').value = itemName;
    document.getElementById('edit-quantity').value = quantity;
    document.getElementById('edit-serial-number').value = serialNumber;
    document.getElementById('edit-model').value = model;
    document.getElementById('edit-warranty').value = warranty;
    document.getElementById('edit-return-date').value = returnDate;
    document.getElementById('edit-return-type').value = type;
    document.getElementById('edit-form').style.display = 'block';
}

// Function to fetch order details via AJAX
function fetchOrderDetails() {
    const orderId = document.getElementById('order-id').value;

    fetch('fetch_order_details.php?order_id=' + orderId)
        .then(response => response.json())
        .then(data => {
            document.getElementById('return-date').value = new Date().toISOString().slice(0, 10);
        })
        .catch(error => console.error('Error fetching order details:', error));
}

// Function to set today's date in the return date input field
function setReturnDate() {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const formattedDate = `${yyyy}-${mm}-${dd}`;
    document.getElementById('return-date').value = formattedDate;
}

// Automatically set the correct tab on page load
window.onload = function () {
    const activeTab = localStorage.getItem('activeTab') || 'supplierReturn'; // Default to 'supplierReturn'
    showTab(activeTab);
    setReturnDate();
};


</script>

</body>
</html>
