<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch KPI data
$totalCustomers = $conn->query("SELECT COUNT(*) as total FROM customers")->fetch_assoc()['total'] ?? 0;
$totalSuppliers = $conn->query("SELECT COUNT(*) as total FROM suppliers")->fetch_assoc()['total'] ?? 0;
$totalSales = $conn->query("SELECT SUM(total) as total FROM billed_items")->fetch_assoc()['total'] ?? 0;
$lowStockCount = $conn->query("SELECT COUNT(*) as total FROM stock WHERE quantity <= 1")->fetch_assoc()['total'] ?? 0;
$totalProducts = $conn->query("SELECT COUNT(*) as total FROM stock")->fetch_assoc()['total'] ?? 0;
$totalOrders = $conn->query("SELECT COUNT(DISTINCT order_id) as total FROM billed_items")->fetch_assoc()['total'] ?? 0;

// Fetch recent products and low-stock items
$recentProducts = $conn->query("SELECT item_name FROM stock ORDER BY id DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$lowStockItems = $conn->query("SELECT item_name, quantity FROM stock WHERE quantity <= 0 LIMIT 5")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Touch Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            color: #333;
        }
        header {
            background-color: #16325B;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 5px solid #fff;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .header-icon {
            font-size: 36px;
        }
        .header-title {
            font-size: 24px;
            font-weight: bold;
        }
        .sidebar {
            background-color: #16325B;
            color: #fff;
            height: 100vh;
            padding-top: 150px;
            padding-left: 10px;
            padding-right: 10px;
            width: 250px;
            border: 5px solid #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .sidebar a {
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            padding: 12px 10px;
            border-radius: 5px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s ease-in-out, transform 0.3s;
        }
        .sidebar a:hover {
            background-color: #0F2747;
            transform: translateX(5px);
        }
        .kpi-card {
            background-color: #16325B;
            color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s ease-in-out, background-color 0.3s ease-in-out;
        }
        .kpi-card:hover {
            transform: translateY(-10px);
            background-color: #0F2747;
        }
        .recent-products, .low-stock-items {
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in-out;
        }
        .list-group-item {
            background-color: #f9f9f9;
            color: #333;
            border: none;
        }
        .list-group-item:hover {
            background-color: #f0f0f0;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
<header>
    <!-- Header Icon and Title -->
    <i class="bi bi-box-seam header-icon"></i>
    <span class="header-title">Smart Touch Inventory</span>

    <!-- Logout Button -->
    <a href="login.php" class="btn btn-danger ms-auto" 
       style="transition: 0.3s; background-color: #dc3545; border-color: #bd2130;" 
       onmouseover="this.style.backgroundColor='#c82333'; this.style.borderColor='#bd2130'" 
       onmouseout="this.style.backgroundColor='#dc3545'; this.style.borderColor='#bd2130'">
       Logout
    </a>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-2 sidebar">
            <nav class="nav flex-column">
                <a href="Billing.php" class="nav-link"><i class="bi bi-receipt"></i> Billing</a>
                <a href="stock.php" class="nav-link"><i class="bi bi-box"></i> Stock Management</a>
                <a href="purchase.php" class="nav-link"><i class="bi bi-cart"></i> Purchase Order</a>
                <a href="ReOrder.php" class="nav-link"><i class="bi bi-bell"></i> Reorder Listing</a>
                <a href="return.php" class="nav-link"><i class="bi bi-arrow-counterclockwise"></i> Returns</a>
                <a href="report.php" class="nav-link"><i class="bi bi-file-earmark-text"></i> Reports</a>
                <a href="warranty.php" class="nav-link"><i class="bi bi-shield-check"></i> Warranty Management</a>
                <a href="supplier_management.php" class="nav-link"><i class="bi bi-people"></i> Supplier Management</a>
                <a href="customer_management.php" class="nav-link"><i class="bi bi-person"></i> Customer Management</a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="col-md-10 p-4">
            <div class="row g-4">
                <!-- KPI Cards -->
                <?php
                $kpis = [
                    ["Total Customers", $totalCustomers],
                    ["Total Suppliers", $totalSuppliers],
                    ["Total Sales", "Rs. " . number_format($totalSales, 2)],
                    ["Low Stock Items", $lowStockCount],
                    ["Total Products", $totalProducts],
                    ["Total Orders", $totalOrders]
                ];
                foreach ($kpis as $kpi): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="kpi-card text-center">
                            <h5><?= $kpi[0] ?></h5>
                            <h2><?= $kpi[1] ?></h2>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <!-- Recent Products and Low Stock Items -->
            <div class="row mt-4">
                <div class="col-md-6 recent-products">
                    <h4>Recent Products</h4>
                    <ul class="list-group">
                        <?php foreach ($recentProducts as $product): ?>
                            <li class="list-group-item"><?= htmlspecialchars($product['item_name']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-md-6 low-stock-items">
                    <h4>Low Stock Items</h4>
                    <ul class="list-group">
                        <?php foreach ($lowStockItems as $item): ?>
                            <li class="list-group-item"><?= htmlspecialchars($item['item_name']) ?> - <?= $item['quantity'] ?> left</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
