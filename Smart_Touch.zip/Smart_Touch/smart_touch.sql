-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2024 at 07:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_touch`
--

-- --------------------------------------------------------

--
-- Table structure for table `billed_items`
--

CREATE TABLE `billed_items` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `serial_number` text NOT NULL,
  `model` text NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `warranty` text DEFAULT NULL,
  `billing_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billed_items`
--

INSERT INTO `billed_items` (`id`, `order_id`, `customer_name`, `product_name`, `quantity`, `price_per_unit`, `discount`, `total`, `serial_number`, `model`, `order_number`, `warranty`, `billing_time`) VALUES
(43, 'ORD-67475499c3712', 'Raazim', 'Dell Inspiron 15', 1, 1200000.00, 3.00, 1164000.00, 'SN001', 'ModelD15', 'PO-00005', '2 years', '2024-11-27 17:19:21');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `phone`, `address`) VALUES
(18, 'Lucas Harris', '0719123456', '134, Sunset Boulevard, Kalutara, SL');

-- --------------------------------------------------------

--
-- Table structure for table `customer_return`
--

CREATE TABLE `customer_return` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `warranty` varchar(255) DEFAULT NULL,
  `return_date` date NOT NULL,
  `return_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `checked_status` varchar(50) DEFAULT 'Unchecked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_return`
--

INSERT INTO `customer_return` (`id`, `order_id`, `customer_name`, `item_name`, `quantity`, `serial_number`, `model`, `warranty`, `return_date`, `return_reason`, `created_at`, `checked_status`) VALUES
(217, 'ORD-674435d3ad2c5', 'Mohammadhu Ramsaan Ahmed Raazim', 'Apple MacBook Pro 14\"', 1, 'SN013', 'ModelMBP14', '1 year', '2024-11-25', 'Quality not satisfactory', '2024-11-25 12:23:40', 'Checked');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `log_date` datetime DEFAULT current_timestamp(),
  `username` varchar(50) NOT NULL,
  `action` varchar(100) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `log_date`, `username`, `action`, `details`) VALUES
(11, '2024-11-25 11:49:00', '123', 'Login', 'User logged in successfully.'),
(12, '2024-11-28 23:14:07', 'Raaz', 'Login', 'User logged in successfully.'),
(13, '2024-11-29 08:50:30', 'Raaz', 'Login', 'User logged in successfully.');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','card') NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','completed') NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `order_id`, `customer_name`, `total_amount`, `amount_paid`, `payment_method`, `transaction_id`, `payment_status`, `payment_date`) VALUES
(10, 'ORD-6741d2d8ce889', 'Ahmed Raazim', 0.00, 60000.00, 'cash', 'INV-6741d325ab43b', 'completed', '2024-11-23 13:05:41'),
(11, 'ORD-674435d3ad2c5', 'Mohammadhu Ramsaan Ahmed Raazim', 0.00, 50000.00, 'cash', 'INV-67443650aad29', 'completed', '2024-11-25 08:33:20');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `product_name`) VALUES
(25, 'Mouse', 'Logitech MX Master 3'),
(30, 'SSD', 'Samsung 970 EVO 1TB'),
(33, 'Monitor', 'Dell UltraSharp U2723QE');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price_per_unit` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `received_quantity` int(11) DEFAULT 0,
  `returned_quantity` int(11) DEFAULT 0,
  `received_serial_numbers` text DEFAULT NULL,
  `returned_serial_numbers` text DEFAULT NULL,
  `received_models` text DEFAULT NULL,
  `returned_models` text DEFAULT NULL,
  `payment_status` enum('Unpaid','Paid') DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `order_number`, `supplier`, `delivery_date`, `item_name`, `quantity`, `price_per_unit`, `total`, `warranty`, `received_quantity`, `returned_quantity`, `received_serial_numbers`, `returned_serial_numbers`, `received_models`, `returned_models`, `payment_status`) VALUES
(48, 'PO-00013', 'Dell', '2024-11-30', 'Icon 3 Dash ', 5, 50000.00, 250000.00, '2', 2, 3, ',SN001,SN002', ',SN003,SN004,SN005', ',Model X,Model Y', ',Model A,Model B,Model C', 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `stock_updated` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `order_number`, `item_name`, `quantity`, `received_date`, `supplier`, `serial_number`, `model`, `warranty`, `stock_updated`) VALUES
(80, 'PO-00013', 'Icon 3 Dash', 2, '2024-11-27', 'Dell', 'SN001,SN002', 'Model X,Model Y', '2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `type`, `email`, `phone`, `address`, `status`, `created_at`) VALUES
(16, 'Rohaka Supplies', 'Manufacturer', 'Rohaka@example.com', '0779876543', 'Rohaka Supply St.', 'Active', '2024-11-27 14:40:52');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_pays`
--

CREATE TABLE `supplier_pays` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `received_quantity` int(11) NOT NULL,
  `returned_quantity` int(11) NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Completed') DEFAULT 'Completed',
  `transaction_id` varchar(100) NOT NULL,
  `payment_method` enum('cash','cheque') NOT NULL,
  `cheque_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_pays`
--

INSERT INTO `supplier_pays` (`id`, `order_number`, `supplier`, `item_name`, `quantity`, `received_quantity`, `returned_quantity`, `price_per_unit`, `total_amount`, `payment_date`, `status`, `transaction_id`, `payment_method`, `cheque_number`) VALUES
(48, 'PO-00001', 'Dell', 'Lenovo PC 2023 ', 5, 3, 2, 45000.00, 135000.00, '2024-11-23 12:47:46', 'Completed', 'CASH-6741cef286946', 'cash', ''),
(49, 'PO-00003', 'Udara Enterprises', 'HP 4500D', 8, 4, 4, 60000.00, 240000.00, '2024-11-23 12:51:23', 'Completed', 'CHQ-6741cfcbb68d1', 'cheque', '12121212');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_return`
--

CREATE TABLE `supplier_return` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `supplier` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `checked_status` varchar(50) DEFAULT 'Unchecked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_return`
--

INSERT INTO `supplier_return` (`id`, `order_number`, `item_name`, `quantity`, `return_date`, `supplier`, `serial_number`, `model`, `warranty`, `checked_status`) VALUES
(11, 'PO-00001', 'Lenovo PC 2023', 2, '2024-11-23', 'Dell', 'LE-876543,LE-324354', 'Lenovo spin,Lenovo spin', '4', 'Unchecked'),
(12, 'PO-00003', 'HP 4500D', 4, '2024-11-23', 'Udara Enterprises', 'HP-353533,HP-544744,HP-164444,HP-564545', '4500D,4500D,4500D,4500D', '4', 'Unchecked'),
(14, 'PO-00013', 'Icon 3 Dash', 3, '2024-11-27', 'Dell', 'SN003,SN004,SN005', 'Model A,Model B,Model C', '2', 'Unchecked');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `transaction_type` enum('purchase','sale') NOT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `supplier_name` varchar(100) DEFAULT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `transaction_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `transaction_type`, `order_number`, `customer_name`, `supplier_name`, `item_name`, `quantity`, `unit_price`, `total_amount`, `transaction_date`) VALUES
(1, 'sale', 'ORD-1001', 'John Doe', NULL, 'Dell Inspiron 15', 1, 75000.00, 75000.00, '2024-11-25 10:30:00'),
(2, 'sale', 'ORD-1002', 'Jane Smith', NULL, 'HP Pavilion x360', 2, 68000.00, 136000.00, '2024-11-25 11:00:00'),
(3, 'purchase', 'PO-2001', NULL, 'Tech World', 'Logitech MX Master 3', 10, 5500.00, 55000.00, '2024-11-26 09:00:00'),
(4, 'sale', 'ORD-1003', 'Michael Brown', NULL, 'Razer BlackWidow V3', 1, 15000.00, 15000.00, '2024-11-26 13:45:00'),
(5, 'purchase', 'PO-2002', NULL, 'Razer Inc.', 'SteelSeries Arctis 7', 5, 10000.00, 50000.00, '2024-11-27 08:15:00'),
(6, 'sale', 'ORD-1004', 'Emily Johnson', NULL, 'Seagate Barracuda 2TB', 3, 6000.00, 18000.00, '2024-11-27 15:30:00'),
(7, 'purchase', 'PO-2003', NULL, 'Samsung Inc.', 'Samsung 970 EVO 1TB', 8, 12000.00, 96000.00, '2024-11-28 10:00:00'),
(8, 'sale', 'ORD-1005', 'Sophia Davis', NULL, 'Lenovo IdeaPad 3', 2, 45000.00, 90000.00, '2024-11-28 16:00:00'),
(9, 'purchase', 'PO-2004', NULL, 'Lenovo Dealers', 'Lenovo ThinkPad E14', 6, 65000.00, 390000.00, '2024-11-29 11:15:00'),
(10, 'sale', 'ORD-1006', 'Robert Wilson', NULL, 'Apple MacBook Pro 14\"', 1, 180000.00, 180000.00, '2024-11-29 17:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `first_name`, `last_name`, `email`, `phone_number`, `created_at`, `updated_at`) VALUES
(6, 'Raaz', 'Raazim', 'admin', 'John', 'Doe', 'Raaz@gmail.com', '0746377892', '2024-11-25 05:56:47', '2024-11-28 18:06:18'),
(9, 'staff1', '456', 'staff', 'Emily', 'Clark', 'emily.clark@example.com', '0744567890', '2024-11-25 05:56:47', '2024-11-28 17:27:31');

-- --------------------------------------------------------

--
-- Table structure for table `warranty_returns`
--

CREATE TABLE `warranty_returns` (
  `return_id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `return_date` date NOT NULL,
  `warranty_end_date` date NOT NULL,
  `comments` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_handed_over` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warranty_returns`
--

INSERT INTO `warranty_returns` (`return_id`, `order_id`, `product_name`, `customer_name`, `return_date`, `warranty_end_date`, `comments`, `created_at`, `is_handed_over`) VALUES
(14, 'ORD-001', 'Dell Inspiron 15', 'John Doe', '2024-11-25', '2025-01-01', 'Hard disk error', '2024-11-25 12:51:47', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billed_items`
--
ALTER TABLE `billed_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `customer_return`
--
ALTER TABLE `customer_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_pays`
--
ALTER TABLE `supplier_pays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_return`
--
ALTER TABLE `supplier_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `warranty_returns`
--
ALTER TABLE `warranty_returns`
  ADD PRIMARY KEY (`return_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billed_items`
--
ALTER TABLE `billed_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customer_return`
--
ALTER TABLE `customer_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `supplier_pays`
--
ALTER TABLE `supplier_pays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `supplier_return`
--
ALTER TABLE `supplier_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `warranty_returns`
--
ALTER TABLE `warranty_returns`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
