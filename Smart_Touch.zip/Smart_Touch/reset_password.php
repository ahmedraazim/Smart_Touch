<?php
session_start();

// Ensure that the reset_username is set in session (i.e., user has passed the verification)
if (!isset($_SESSION['reset_username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle reset password form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if both passwords match
    if ($newPassword === $confirmPassword) {
        // Update the password in the database
        $username = $_SESSION['reset_username'];
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $newPassword, $username);
        $stmt->execute();
        $stmt->close();

        // Unset session variable and redirect to login
        unset($_SESSION['reset_username']);
        header("Location: login.php?password_reset=success");
        exit();
    } else {
        $error = "Passwords do not match!";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(to right, #0066cc, #00408e);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        header {
            background-color: #00408e;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: absolute;
            width: 100%;
            top: 0;
        }
        .header-title {
            font-size: 24px;
        }
        .reset-container {
            background: white;
            padding: 40px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }
        .reset-container h2 {
            margin-bottom: 20px;
            color: #00408e;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #00408e;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .button {
            width: 100%;
            padding: 10px; /* Same padding for both buttons */
            color: white;
            border: 2px solid #00408e; /* Add border */
            border-radius: 8px; /* Rounded corners */
            font-weight: bold; /* Make text bold */
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease; /* Add transition effect */
            margin-top: 10px; /* Space between buttons */
            font-size: 18px; /* Font size for buttons */
        }

        .reset-button {
            background-color: #00408e; /* Color for reset button */
            margin-bottom: 20px; /* Space below reset button */
        }

        .reset-button:hover {
            background-color: #0066cc; /* Hover effect for reset button */
            transform: scale(1.05); /* Slightly enlarge the button on hover */
        }

        .back-button {
            background-color: #666; /* Color for back button */
            text-decoration: none; /* Remove underline */
        }

        .back-button:hover {
            background-color: #888; /* Hover effect for back button */
            transform: scale(1.05); /* Slightly enlarge the button on hover */
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }
        footer {
            background-color: #00408e;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header style="display: flex; justify-content: center; align-items: center;">
    <div style="display: flex; align-items: center;">
        <img src="logo/Batch.PNG" alt="Logo" width="50">
        <span class="header-title">Smart Touch</span>
    </div>
</header>

<div class="reset-container">
    <h2>Reset Password</h2>
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST" action="reset_password.php">
        <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" name="new_password" required>
        </div>
        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" name="confirm_password" required>
        </div>
        <button type="submit" class="button reset-button">Reset Password</button> <!-- Reset Password Button -->
    </form>
    
    <a href="login.php" class="button back-button">Back to Login</a> <!-- Back to Login Button -->
</div>

<footer>
    &copy; 2024 Smart Touch Inventory. All rights reserved.
</footer>

</body>
</html>
