<?php
// Display errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Smart_Touch";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to register a new user
function register($username, $password, $email, $full_name, $role_id) {
    global $conn;
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $email = mysqli_real_escape_string($conn, $email);
    $full_name = mysqli_real_escape_string($conn, $full_name);
    
    $sql = "INSERT INTO users (username, password, email, full_name) VALUES ('$username', '$password', '$email', '$full_name')";
    
    if ($conn->query($sql) === TRUE) {
        // New user registered successfully
        $user_id = $conn->insert_id;
        $sql_role = "INSERT INTO user_role_mapping (user_id, role_id) VALUES ('$user_id', '$role_id')";
        if ($conn->query($sql_role) === TRUE) {
            return true;
        } else {
            return false;
        }
    } else {
        // Error in registration
        return false;
    }
}

// Handle registration request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Role mapping (assumed to be predefined in your database)
    $role_id = ($role === 'Admin') ? 1 : 2;
    function isUserExists($username, $email) {
        // Your database connection and query to check if the user exists
        // Example using PDO (adjust as necessary for your setup)
        $pdo = new PDO('mysql:host=localhost;dbname=smart_touch', 'root', '');
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = :username OR email = :email');
        $stmt->execute(['username' => $username, 'email' => $email]);
        $count = $stmt->fetchColumn();
    
        return $count > 0;
    }
    
    if (isUserExists($username, $email)) {
        echo '<div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
                <span style="font-size: 50px; font-weight: bold; color: red;">User already exists!</span>
              </div>';
    } else {
        if (register($username, $password, $email, $full_name, $role_id)) {
            echo '<div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
                    <span style="font-size: 50px; font-weight: bold; color: green;">Registration successful!</span>
                  </div>';
        } else {
            echo '<div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
                    <span style="font-size: 50px; font-weight: bold; color: red;">Registration failed!</span>
                  </div>';
        }
    }
    
    
    
}

// Close database connection
$conn->close();
?>
