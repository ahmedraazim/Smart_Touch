<?php
session_start();
include 'db_connection.php'; // Include database connection

require_once 'vendor/tecnickcom/tcpdf/tcpdf.php'; // Include TCPDF library

// Initialize messages
$successMessage = "";
$errorMessage = "";
$redirectTo = false;

// Pagination Variables
$recordsPerPage = 7; // Show 7 records per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $recordsPerPage;

// Search Functionality
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch payment records
$sql = "SELECT * FROM supplier_pays WHERE 1";
if (!empty($searchQuery)) {
    $sql .= " AND (order_number LIKE '%$searchQuery%' OR supplier LIKE '%$searchQuery%' OR transaction_id LIKE '%$searchQuery%')";
}
$totalRecords = $conn->query("SELECT COUNT(*) AS total FROM ($sql) AS subquery")->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $recordsPerPage);
$sql .= " LIMIT $offset, $recordsPerPage";
$paymentRecords = $conn->query($sql);

// Fetch order details if order number is provided
$orderNumber = isset($_GET['order_number']) ? $_GET['order_number'] : '';
$supplier = '';
$totalBillAmount = 0;
$items = [];

if (!empty($orderNumber)) {
    $stmt = $conn->prepare("SELECT supplier, item_name, quantity, received_quantity, returned_quantity, price_per_unit FROM purchase_orders WHERE order_number = ?");
    $stmt->bind_param("s", $orderNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $supplier = $row['supplier'];
        $receivedTotal = $row['received_quantity'] * $row['price_per_unit'];
        $totalBillAmount += $receivedTotal;
        $items[] = array_merge($row, ['received_total' => $receivedTotal]);
    }
    $stmt->close();
} else {
    $errorMessage = "Order number is not specified.";
}

// Process payment
if (isset($_POST['make_payment'])) {
    $paymentMethod = $_POST['payment_method'];
    $orderNumber = $_POST['order_number'];
    $supplier = $_POST['supplier'];
    $transactionId = null;
    $chequeNumber = $_POST['cheque_number'] ?? null;

    // Validate payment method
    if ($paymentMethod == 'cheque' && empty($chequeNumber)) {
        $errorMessage = "Cheque number is required for cheque payments.";
    } else {
        if ($paymentMethod == 'cash') {
            $transactionId = "CASH-" . uniqid();
        } elseif ($paymentMethod == 'cheque') {
            $transactionId = "CHQ-" . uniqid();
        }

        if ($transactionId) {
            foreach ($items as $item) {
                $stmt = $conn->prepare("INSERT INTO supplier_pays 
                    (order_number, supplier, item_name, quantity, received_quantity, returned_quantity, price_per_unit, total_amount, payment_date, status, transaction_id, payment_method, cheque_number) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'Completed', ?, ?, ?)");
                $stmt->bind_param(
                    "sssiiidssss",
                    $orderNumber,
                    $supplier,
                    $item['item_name'],
                    $item['quantity'],
                    $item['received_quantity'],
                    $item['returned_quantity'],
                    $item['price_per_unit'],
                    $item['received_total'],
                    $transactionId,
                    $paymentMethod,
                    $chequeNumber
                );

                if ($stmt->execute()) {
                    $successMessage = "Payment Successful!";
                    $redirectTo = true;
                } else {
                    $errorMessage = "Error saving payment: " . $stmt->error;
                    break;
                }
            }

            if ($successMessage) {
                $updateStatusStmt = $conn->prepare("UPDATE purchase_orders SET payment_status = 'Paid' WHERE order_number = ?");
                $updateStatusStmt->bind_param("s", $orderNumber);
                $updateStatusStmt->execute();
                $updateStatusStmt->close();
            }

            if ($successMessage) {
                generateReceiptPDF($orderNumber, $supplier, $totalBillAmount, $paymentMethod, $transactionId, $chequeNumber, $items);
                exit;
            }
        }
    }
}

// Generate receipt PDF
function generateReceiptPDF($orderNumber, $supplier, $totalBillAmount, $paymentMethod, $transactionId, $chequeNumber, $items) {
    $pdf = new \TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Smart Touch');
    $pdf->SetTitle('Payment Receipt');
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    $html = <<<EOD
    <style>
        .header { text-align: center; color: #00408e; font-size: 20px; }
        .table { border: 1px solid #ccc; width: 100%; margin-top: 10px; border-collapse: collapse; }
        .table th { background-color: #007bff; color: white; padding: 8px; border: 1px solid #ddd; }
        .table td { padding: 8px; text-align: center; border: 1px solid #ddd; }
    </style>
    <div class="header"><h1>Payment Receipt</h1></div>
    <div>
        <p>Supplier: $supplier</p>
        <p>Order Number: $orderNumber</p>
        <p>Total Bill Amount: $totalBillAmount</p>
        <p>Payment Method: $paymentMethod</p>
        <p>Transaction ID: $transactionId</p>
EOD;

    if ($paymentMethod === 'cheque') {
        $html .= "<p>Cheque Number: $chequeNumber</p>";
    }

    $html .= <<<EOD
    </div>
    <table class="table">
        <thead><tr><th>Item Name</th><th>Quantity</th><th>Price per Unit</th><th>Total</th></tr></thead>
        <tbody>
EOD;

    foreach ($items as $item) {
        $html .= "<tr>
            <td>{$item['item_name']}</td>
            <td>{$item['received_quantity']}</td>
            <td>{$item['price_per_unit']}</td>
            <td>{$item['received_total']}</td>
        </tr>";
    }

    $html .= "</tbody></table><p>Thank you for your business!</p>";
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output("Receipt_$orderNumber.pdf", 'D');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Suppliers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
<a href="purchase.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Purchase Order</a>

    <h2>Pay Suppliers</h2>

    <?php if ($successMessage): ?>
        <div class="alert alert-success"><?= $successMessage ?></div>
        <script>setTimeout(() => window.location.href = 'purchase.php', 5000);</script>
    <?php elseif ($errorMessage): ?>
        <div class="alert alert-danger"><?= $errorMessage ?></div>
    <?php endif; ?>

    <?php if (!empty($orderNumber)): ?>
        <form method="POST">
            <input type="hidden" name="order_number" value="<?= htmlspecialchars($orderNumber) ?>">
            <input type="hidden" name="supplier" value="<?= htmlspecialchars($supplier) ?>">

            <h4>Order Summary</h4>
            <table class="table table-bordered">
                <thead><tr><th>Item Name</th><th>Quantity</th><th>Price per Unit</th><th>Total</th></tr></thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['item_name']) ?></td>
                            <td><?= htmlspecialchars($item['received_quantity']) ?></td>
                            <td><?= number_format($item['price_per_unit'], 2) ?></td>
                            <td><?= number_format($item['received_total'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr><th colspan="3">Total</th><th><?= number_format($totalBillAmount, 2) ?></th></tr>
                </tfoot>
            </table>

            <h4>Payment</h4>
            <div class="form-check">
                <input type="radio" id="cash" name="payment_method" value="cash" class="form-check-input" onclick="toggleFields('cash')" required>
                <label for="cash" class="form-check-label">Cash</label>
            </div>
            <div class="form-check">
                <input type="radio" id="cheque" name="payment_method" value="cheque" class="form-check-input" onclick="toggleFields('cheque')" required>
                <label for="cheque" class="form-check-label">Cheque</label>
            </div>
            <div id="chequeField" style="display:none;">
                <label>Cheque Number:</label>
                <input type="text" name="cheque_number" class="form-control">
            </div>
            <button type="submit" name="make_payment" class="btn btn-primary mt-3">Pay Now</button>
        </form>
    <?php endif; ?>

    <h3 class="mt-5">Search Payments</h3>
    <form method="GET">
        <div class="mb-3">
            <input type="text" name="search" value="<?= htmlspecialchars($searchQuery) ?>" placeholder="Search by Order Number, Supplier, or Transaction ID" class="form-control">
        </div>
        <button type="submit" class="btn btn-secondary">Search</button>
    </form>

    <h3 class="mt-5">Previous Payments</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order Number</th>
                <th>Supplier</th>
                <th>Amount</th>
                <th>Payment Date</th>
                <th>Transaction ID</th>
                <th>Payment Method</th>
                <th>Cheque Number</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($record = $paymentRecords->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($record['order_number']) ?></td>
                    <td><?= htmlspecialchars($record['supplier']) ?></td>
                    <td><?= number_format($record['total_amount'], 2) ?></td>
                    <td><?= htmlspecialchars($record['payment_date']) ?></td>
                    <td><?= htmlspecialchars($record['transaction_id']) ?></td>
                    <td><?= htmlspecialchars($record['payment_method']) ?></td>
                    <td><?= htmlspecialchars($record['cheque_number']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <nav>
        <ul class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= $i == $currentPage ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($searchQuery) ?>"><?= $i ?></a></li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<script>
    function toggleFields(method) {
        document.getElementById('chequeField').style.display = method === 'cheque' ? 'block' : 'none';
    }
</script>
</body>
</html>
