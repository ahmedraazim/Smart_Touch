<?php
session_start();
include 'db_connection.php'; // Include your database connection file

// Include Composer's autoloader for Stripe and TCPDF
require 'vendor/autoload.php';

// Initialize variables
$errorMessage = '';
$successMessage = '';
$orderId = ''; // Initialize orderId to prevent undefined variable warning
$customerName = ''; // Initialize customerName
$totalAmount = 0.00; // Initialize $totalAmount

// Fetch order details based on order_id from query string
if (isset($_GET['order_id']) && isset($_GET['customerName'])) {
    $orderId = $_GET['order_id'];
    $customerName = $_GET['customerName'];

    // Fetch the total billed amount from the billed_items table
    $stmt = $conn->prepare("SELECT SUM(total) AS totalAmount FROM billed_items WHERE order_id = ?");
    $stmt->bind_param("s", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $totalAmount = $row['totalAmount']; // Get the total amount for the order
} else {
    $errorMessage = "Invalid request. Missing order_id or customerName.";
}

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['processPayment'])) {
    $paymentMethod = $_POST['paymentMethod'];
    $orderId = $_POST['order_id'];
    $customerName = $_POST['customerName'];
    $amountPaid = isset($_POST['amountPaid']) ? (float)$_POST['amountPaid'] : (float)$totalAmount;

    // Check if amount paid is less than the total amount
    if ($amountPaid < $totalAmount) {
        $errorMessage = "Amount paid cannot be less than the total amount.";
    } else {
        $balance = $amountPaid - $totalAmount; // Calculate balance

        // Generate a unique invoice number (transaction_id) for each invoice
        $transactionId = uniqid('INV-');

        if ($paymentMethod === 'cash') {
            // Process cash payment
            $stmt = $conn->prepare("INSERT INTO payments (order_id, customer_name, amount_paid, payment_method, transaction_id, payment_status) VALUES (?, ?, ?, ?, ?, 'completed')");
            $stmt->bind_param("ssdss", $orderId, $customerName, $amountPaid, $paymentMethod, $transactionId);
            if ($stmt->execute()) {
                $successMessage = "Payment successful!";
            } else {
                $errorMessage = "Failed to process payment.";
            }
        }

        if ($paymentMethod === 'card') {
            \Stripe\Stripe::setApiKey('sk_test_XXXXXXXXXXXXXXXXXXXXXXXX'); // Replace with your secret key

            try {
                // Create the charge on Stripe
                $charge = \Stripe\Charge::create([
                    'amount' => $totalAmount * 100, // Stripe requires amount in cents
                    'currency' => 'usd',
                    'source' => $_POST['stripeToken'],
                    'description' => "Payment for Order ID: $orderId"
                ]);

                // Insert payment record into payments table with transaction ID
                $stmt = $conn->prepare("INSERT INTO payments (order_id, customer_name, amount_paid, payment_method, transaction_id, payment_status) VALUES (?, ?, ?, ?, ?, 'completed')");
                $stmt->bind_param("ssdss", $orderId, $customerName, $totalAmount, $paymentMethod, $charge->id);
                if ($stmt->execute()) {
                    $successMessage = "Card payment successful!";
                } else {
                    $errorMessage = "Failed to process payment.";
                }
            } catch (\Stripe\Exception\CardException $e) {
                $errorMessage = "Payment failed: " . $e->getError()->message;
            }
        }
    }
}

function generateInvoicePDF($orderId, $customerName, $totalAmount, $amountPaid, $balance, $conn) {
    // Include TCPDF library
    require_once 'vendor/tecnickcom/tcpdf/tcpdf.php';

    // Fetch billed items from the database
    $stmt = $conn->prepare("SELECT product_name, quantity, price_per_unit, total FROM billed_items WHERE order_id = ?");
    $stmt->bind_param("s", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Initialize TCPDF
    $pdf = new \TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Smart Touch');
    $pdf->SetTitle('Invoice');
    $pdf->SetSubject('Invoice for Order ' . $orderId);

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Header section
    $html = <<<EOD
    <style>
        .header {
            text-align: center;
            color: #00408e;
            font-size: 20px;
        }
        .subheader {
            text-align: center;
            color: #333;
            font-size: 12px;
        }
        .invoice-title {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }
        .details {
            margin: 10px 0;
            font-size: 12px;
        }
        .details p {
            margin: 3px 0;
        }
        .table {
            border: 1px solid #ccc;
            border-collapse: collapse;
            width: 100%;
            margin-top: 10px;
        }
        .table th {
            background-color: #007bff;
            color: white;
            border: 1px solid #ddd;
            text-align: center;
            padding: 8px;
        }
        .table td {
            border: 1px solid #ddd;
            text-align: center;
            padding: 8px;
        }
        .total-row {
            font-weight: bold;
            text-align: center;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 12px;
            color: #555;
        }
        .footer .thank-you {
            font-weight: bold;
            font-size: 14px;
            color: #333;
        }
        .footer .quote {
            font-style: italic;
            color: #007bff;
        }
    </style>
    <div class="header">
        <h1>Smart Touch</h1>
    </div>
    <div class="subheader">
        <p>Email: smart0000touch@gmail.com</p>
        <p>Phone: +94 76 3939 272</p>
        <p>Address: # Kandy Road, Sri Lanka. 20000</p>
    </div>
    <div class="invoice-title">
        Invoice for Order: $orderId
    </div>
    <div class="details">
        <p><strong>Customer Name:</strong> $customerName</p>
        <p><strong>Order ID:</strong> $orderId</p>
        <p><strong>Total Amount:</strong> $totalAmount</p>
        <p><strong>Amount Paid:</strong> $amountPaid</p>
        <p><strong>Balance:</strong> $balance</p>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price per Unit</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
EOD;

    // Add table rows with order details
    while ($row = $result->fetch_assoc()) {
        $html .= "<tr>
                    <td>" . htmlspecialchars($row['product_name']) . "</td>
                    <td>" . htmlspecialchars($row['quantity']) . "</td>
                    <td>" . number_format($row['price_per_unit'], 2) . "</td>
                    <td>" . number_format($row['total'], 2) . "</td>
                  </tr>";
    }

    // Add totals
    $html .= <<<EOD
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="3">Total Amount</td>
                <td>$totalAmount</td>
            </tr>
        </tfoot>
    </table>
    <div class="footer">
        <p class="thank-you">Thank you for choosing Smart Touch!</p>
        <p class="quote">"Great things in business are never done by one person; they're done by a team of people." – Steve Jobs</p>
    </div>
EOD;

    // Write the HTML content to the PDF
    $pdf->writeHTML($html, true, false, true, false, '');

    // Output the PDF for download
    $pdf->Output("Invoice_$orderId.pdf", 'D'); // 'D' forces download
}

// Handle invoice generation request
if (isset($_GET['generatePDF'])) {
    $amountPaid = (float)$_GET['amountPaid'];
    $balance = $amountPaid - $totalAmount;
    generateInvoicePDF($orderId, $customerName, $totalAmount, $amountPaid, $balance, $conn);
    exit; // Stop the script after generating the PDF
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>
<div class="container mt-5">
<a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>

    <h2 class="text-center mb-4">Payment for Order: <?= htmlspecialchars($orderId) ?></h2>

    <!-- Success and Error Messages -->
    <div id="message-box">
        <?php if (!empty($successMessage)): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($successMessage); ?>
            </div>
        <?php elseif (!empty($errorMessage)): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($errorMessage); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Payment Form -->
    <div class="card">
        <div class="card-header bg-primary text-white">Payment Details</div>
        <div class="card-body">
            <form id="paymentForm" method="POST" action="payment.php">
                <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderId) ?>">
                <input type="hidden" name="customerName" value="<?= htmlspecialchars($customerName) ?>">
                <input type="hidden" name="totalAmount" value="<?= htmlspecialchars($totalAmount) ?>">

                <div class="mb-3">
                    <label for="totalAmount" class="form-label">Total Amount for the order</label>
                    <input type="text" class="form-control" id="totalAmount" value="<?= number_format($totalAmount, 2) ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="paymentMethod" class="form-label">Payment Method</label>
                    <select class="form-select" name="paymentMethod" id="paymentMethod" required>
                        <option value="" disabled selected>Select a payment option</option>
                        <option value="cash">Cash</option>
                        <option value="card">Card</option>
                    </select>
                </div>

                <!-- Card Details Input (Stripe) -->
                <div id="stripe-card-details" style="display: none;">
                    <div class="mb-3">
                        <label for="card-element" class="form-label">Card Number</label>
                        <div id="card-element" class="form-control"></div>
                        <small id="card-errors" class="form-text text-danger"></small>
                    </div>
                </div>

                <!-- Amount Paid for Cash Payments -->
                <div id="cash-amount" style="display: none;">
                    <div class="mb-3">
                        <label for="amountPaid" class="form-label">Amount Paid</label>
                        <input type="number" class="form-control" name="amountPaid" id="amountPaid" step="0.01" min="<?= number_format($totalAmount, 2) ?>" required>
                    </div>
                </div>

                <!-- Submit Payment Button -->
                <button type="submit" name="processPayment" class="btn btn-success">Submit Payment</button>
            </form>
        </div>
    </div>
</div>

<!-- Display Invoice after payment -->
<?php if (!empty($successMessage)): ?>
    <div class="container mt-5">
        <h3 class="text-center">Invoice</h3>
        <div class="d-flex justify-content-center">
            <form action="payment.php" method="GET">
                <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderId) ?>">
                <input type="hidden" name="customerName" value="<?= htmlspecialchars($customerName) ?>">
                <input type="hidden" name="amountPaid" value="<?= htmlspecialchars($amountPaid) ?>">
                <button type="submit" name="generatePDF" class="btn btn-primary">Download Invoice as PDF</button>
            </form>
        </div>
    </div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script>
    // Show/Hide Stripe card details form based on selected payment method
    document.getElementById('paymentMethod').addEventListener('change', function() {
        if (this.value === 'card') {
            document.getElementById('stripe-card-details').style.display = 'block';
            document.getElementById('cash-amount').style.display = 'none';
        } else {
            document.getElementById('stripe-card-details').style.display = 'none';
            document.getElementById('cash-amount').style.display = 'block';
        }
    });

    // Stripe Integration for Card Payments
    const stripe = Stripe('pk_test_XXXXXXXXXXXXXXXXXXXXXXXX');
    const elements = stripe.elements();
    const cardElement = elements.create('card');
    cardElement.mount('#card-element');
</script>
</body>
</html>