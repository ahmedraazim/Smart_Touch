<?php
session_start();

// Ensure that the user is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all users for display
$userQuery = "SELECT user_id, username, email, role, first_name, last_name, phone_number FROM users";
$userResult = $conn->query($userQuery);

// Fetch logs for display
$logQuery = "SELECT log_id, log_date, username, action, details FROM logs"; // Sample log table
$logResult = $conn->query($logQuery);

// Handle user addition/update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['deleteUser'])) {
        $userIdToDelete = $_POST['userIdToDelete'];
        $deleteStmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $deleteStmt->bind_param("i", $userIdToDelete);
        $deleteStmt->execute();
        $deleteStmt->close();
        header("Location: admin.php");
        exit();
    }
    // Handle user addition/update
    $userId = isset($_POST['userId']) ? $_POST['userId'] : ''; // For edit operation
    $userName = $_POST['userName'];    $userEmail = $_POST['userEmail'];    $userRole = $_POST['userRole'];    
    $firstName = $_POST['firstName'];    
    $lastName = $_POST['lastName'];    $phoneNumber = $_POST['phoneNumber'];    $defaultPassword = "12345"; 

    if (empty($userId)) {
        $stmt = $conn->prepare("INSERT INTO users (username, email, role, first_name, last_name, phone_number, password) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $userName, $userEmail, $userRole, $firstName, $lastName, $phoneNumber, $defaultPassword);
    } else {
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ?, first_name = ?, last_name = ?, 
        phone_number = ? WHERE user_id = ?");
        $stmt->bind_param("ssssssi", $userName, $userEmail, $userRole, $firstName, $lastName, $phoneNumber, $userId);
    }
    if ($stmt->execute()) {
        header("Location: admin.php");
        exit();
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php include 'header.php'; ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        .nav-tabs {
            margin-bottom: 20px;
        }
        .tab-content {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .tab-pane {
            display: none;
        }
        .tab-pane.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Exit and Reports Buttons -->
        <div class="d-flex justify-content-end mb-3">
            <a href="report.php" class="btn btn-info mr-2" style="background-color: #00408e; color: #fff;">Reports</a>
            <a href="login.php" class="btn btn-danger" style="transition: 0.3s; background-color: #dc3545; border-color: #bd2130;" onmouseover="this.style.backgroundColor='#c82333'; this.style.borderColor='#bd2130'" onmouseout="this.style.backgroundColor='#dc3545'; this.style.borderColor='#bd2130'">Logout</a>
            </div>
        <h2>Admin Dashboard</h2>
        
        <ul class="nav nav-tabs" id="adminTabs">
            <li class="nav-item">
                <a class="nav-link active" href="#" onclick="showTab('manageUsers')">Manage Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" onclick="showTab('viewLogs')">View Logs</a>
            </li>
        </ul>

        <div class="tab-content">
            <div id="manageUsers" class="tab-pane active">
                <h3>Manage Users</h3>
                <form id="userForm" method="POST" action="admin.php">
                    <input type="hidden" id="userId" name="userId" value=""> <!-- Hidden input for editing -->
                    <div class="form-group">
                        <label for="userName">User Name</label>
                        <input type="text" class="form-control" id="userName" name="userName" required>
                    </div>
                    <div class="form-group">
                        <label for="userEmail">User Email</label>
                        <input type="email" class="form-control" id="userEmail" name="userEmail" required>
                    </div>
                    <div class="form-group">
                        <label for="userRole">User Role</label>
                        <select class="form-control" id="userRole" name="userRole" required>
                            <option value="Admin">Admin</option>
                            <option value="Staff">Staff</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="firstName">First Name</label>
                        <input type="text" class="form-control" id="firstName" name="firstName" required>
                    </div>
                    <div class="form-group">
                        <label for="lastName">Last Name</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" required>
                    </div>
                    <div class="form-group">
                        <label for="phoneNumber">Phone Number</label>
                        <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

                <!-- Search Functionality -->
                <div class="form-group" style="margin-top: 20px;">
                    <label for="searchInput">Search Users</label>
                    <input type="text" class="form-control" id="searchInput" onkeyup="searchUsers()" placeholder="Search by username or email">
                </div>

                <div class="table-responsive" style="margin-top: 20px;">
                    <table class="table table-bordered" id="userTable">
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Phone Number</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($userResult->num_rows > 0) {
                                while ($row = $userResult->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo $row['user_id']; ?></td>
                                        <td><?php echo $row['username']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><?php echo $row['role']; ?></td>
                                        <td><?php echo $row['first_name']; ?></td>
                                        <td><?php echo $row['last_name']; ?></td>
                                        <td><?php echo $row['phone_number']; ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="editUser(<?php echo $row['user_id']; ?>, '<?php echo $row['username']; ?>', '<?php echo $row['email']; ?>', '<?php echo $row['role']; ?>', '<?php echo $row['first_name']; ?>', '<?php echo $row['last_name']; ?>', '<?php echo $row['phone_number']; ?>')">Edit</button>

                                            <!-- Delete Form -->
                                            <form method="POST" action="admin.php" style="display:inline;">
                                                <input type="hidden" name="userIdToDelete" value="<?php echo $row['user_id']; ?>">
                                                <button type="submit" class="btn btn-danger" name="deleteUser">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="viewLogs" class="tab-pane">
                <h3>View Logs</h3>

                <!-- Search Functionality for Logs -->
                <div class="form-group">
                    <label for="searchLogInput">Search Logs</label>
                    <input type="text" class="form-control" id="searchLogInput" onkeyup="searchLogs()" placeholder="Search by username or action">
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Log ID</th>
                                <th>Date</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody id="logTable">
                            <?php if ($logResult->num_rows > 0) {
                                while ($log = $logResult->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo $log['log_id']; ?></td>
                                        <td><?php echo $log['log_date']; ?></td>
                                        <td><?php echo $log['username']; ?></td>
                                        <td><?php echo $log['action']; ?></td>
                                        <td><?php echo $log['details']; ?></td>
                                    </tr>
                                <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    function showTab(tabId) {
        const tabs = document.querySelectorAll('.tab-pane');
        tabs.forEach(tab => tab.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
    }

    function editUser(userID, userName, userEmail, userRole, firstName, lastName, phoneNumber) {
        document.getElementById('userId').value = userID; // Set hidden user ID
        document.getElementById('userName').value = userName;
        document.getElementById('userEmail').value = userEmail;
        document.getElementById('userRole').value = userRole;
        document.getElementById('firstName').value = firstName; // Set first name
        document.getElementById('lastName').value = lastName; // Set last name
        document.getElementById('phoneNumber').value = phoneNumber; // Set phone number
        document.getElementById('userForm').scrollIntoView();
    }

    function searchUsers() {
        const input = document.getElementById('searchInput').value.toLowerCase();
        const table = document.getElementById('userTable').getElementsByTagName('tbody')[0];
        const rows = table.getElementsByTagName('tr');

        for (let i = 0; i < rows.length; i++) {
            const userName = rows[i].getElementsByTagName('td')[1].textContent.toLowerCase();
            const userEmail = rows[i].getElementsByTagName('td')[2].textContent.toLowerCase();
            if (userName.includes(input) || userEmail.includes(input)) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }

    function searchLogs() {
        const input = document.getElementById('searchLogInput').value.toLowerCase();
        const table = document.getElementById('logTable');
        const rows = table.getElementsByTagName('tr');

        for (let i = 0; i < rows.length; i++) {
            const logUser = rows[i].getElementsByTagName('td')[2].textContent.toLowerCase();
            const logAction = rows[i].getElementsByTagName('td')[3].textContent.toLowerCase();
            if (logUser.includes(input) || logAction.includes(input)) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }
    </script>


</body>
</html>
