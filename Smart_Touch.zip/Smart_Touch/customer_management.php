<?php
session_start();
include 'db_connection.php'; // Include your database connection file
include 'header.php'; 

// Initialize message variables
$successMessage = "";
$errorMessage = "";

// Handle delete customer request
if (isset($_POST['delete_customer'])) {
    $customerId = $_POST['customer_id'];
    $deleteQuery = $conn->prepare("DELETE FROM customers WHERE id = ?");
    $deleteQuery->bind_param("i", $customerId);
    if ($deleteQuery->execute()) {
        $successMessage = "Customer deleted successfully!";
    } else {
        $errorMessage = "Error deleting customer.";
    }
}

// Handle update customer request
if (isset($_POST['update_customer'])) {
    $customerId = $_POST['customer_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);

    $updateQuery = $conn->prepare("UPDATE customers SET name = ?, phone = ?, address = ? WHERE id = ?");
    $updateQuery->bind_param("sssi", $name, $phone, $address, $customerId);
    if ($updateQuery->execute()) {
        $successMessage = "Customer updated successfully!";
    } else {
        $errorMessage = "Error updating customer.";
    }
}

// Handle search
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$searchQuery = $searchTerm ? "WHERE name LIKE '%$searchTerm%' OR phone LIKE '%$searchTerm%' OR address LIKE '%$searchTerm%'" : '';
$query = "SELECT * FROM customers $searchQuery ORDER BY id DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Ensure table header text is white */
        table thead th {
            color: #fff !important;
        }

        body {
            background-color: #f4f6f9;
        }

        .btn-back {
            background-color: #00408e;
            color: #fff;
        }
        
        .table thead {
            background-color: #00408e;
        }
    </style>
</head>
<body>
    
<div class="container mt-5">
    <div class="mb-3">
        <a href="Inventory.php" class="btn btn-back mb-2">Back to Home</a>
    </div>

    <h2>Customer Management</h2>

    <!-- Success and Error Messages -->
    <?php if ($successMessage): ?>
        <div id="successMessage" class="alert alert-success"><?= $successMessage ?></div>
    <?php elseif ($errorMessage): ?>
        <div id="errorMessage" class="alert alert-danger"><?= $errorMessage ?></div>
    <?php endif; ?>

    <!-- Search Bar -->
    <form method="GET" action="customer_management.php" class="mb-4">
        <div class="input-group">
            <input type="text" class="form-control" name="search" placeholder="Search by name, phone, or address" value="<?= htmlspecialchars($searchTerm) ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Customer Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($customer = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($customer['name']); ?></td>
                    <td><?= htmlspecialchars($customer['phone']); ?></td>
                    <td><?= htmlspecialchars($customer['address']); ?></td>
                    <td>
                        <!-- Edit button to open modal -->
                        <button class="btn btn-warning btn-sm" onclick="editCustomer(<?= $customer['id']; ?>, '<?= htmlspecialchars($customer['name']); ?>', '<?= htmlspecialchars($customer['phone']); ?>', '<?= htmlspecialchars($customer['address']); ?>')">Edit</button>

                        <!-- Delete form -->
                        <form method="POST" action="customer_management.php" style="display:inline;">
                            <input type="hidden" name="customer_id" value="<?= $customer['id']; ?>">
                            <button type="submit" name="delete_customer" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this customer?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="customer_management.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="customer_id" id="editCustomerId">
                    <div class="mb-3">
                        <label for="editCustomerName" class="form-label">Name</label>
                        <input type="text" class="form-control" name="name" id="editCustomerName" required>
                    </div>
                    <div class="mb-3">
                        <label for="editCustomerPhone" class="form-label">Phone</label>
                        <input type="text" class="form-control" name="phone" id="editCustomerPhone" required>
                    </div>
                    <div class="mb-3">
                        <label for="editCustomerAddress" class="form-label">Address</label>
                        <input type="text" class="form-control" name="address" id="editCustomerAddress" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="update_customer" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script>
    // Open modal with customer data for editing
    function editCustomer(id, name, phone, address) {
        document.getElementById('editCustomerId').value = id;
        document.getElementById('editCustomerName').value = name;
        document.getElementById('editCustomerPhone').value = phone;
        document.getElementById('editCustomerAddress').value = address;
        new bootstrap.Modal(document.getElementById('editModal')).show();
    }

    // Hide success or error message after 6 seconds
    document.addEventListener("DOMContentLoaded", function () {
        const successMessage = document.getElementById("successMessage");
        const errorMessage = document.getElementById("errorMessage");

        if (successMessage) {
            setTimeout(() => {
                successMessage.style.display = "none";
            }, 6000);
        }

        if (errorMessage) {
            setTimeout(() => {
                errorMessage.style.display = "none";
            }, 6000);
        }
    });
</script>
</body>
</html>
