<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
S
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Fetch order details from billed_items table
    $stmt = $conn->prepare("SELECT customer_name, product_name, quantity, serial_number, model, warranty FROM billed_items WHERE order_id = ?");
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->bind_result($customer_name, $product_name, $quantity, $serial_number, $model, $warranty);
    $stmt->fetch();
    $stmt->close();

    // Return data as JSON
    echo json_encode([
        'customer_name' => $customer_name,
        'product_name' => $product_name,
        'quantity' => $quantity,
        'serial_number' => $serial_number,
        'model' => $model,
        'warranty' => $warranty
    ]);
}

$conn->close();
?>
