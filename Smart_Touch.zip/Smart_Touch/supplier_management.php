<?php
session_start();

// Include header file
include 'header.php';

// Generate CSRF token
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle CRUD operations for suppliers
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['token']) {
        die("CSRF token validation failed.");
    }

    $supplier_id = isset($_POST['supplierID']) && !empty($_POST['supplierID']) ? $_POST['supplierID'] : 0;
    $name = $_POST['supplierName'];
    $type = $_POST['supplierType'];
    $email = $_POST['contactEmail'];
    $phone = $_POST['contactPhone'];
    $address = $_POST['address'];
    $status = $_POST['supplierStatus'];

    if ($_POST['action'] == 'add_supplier' && $supplier_id == 0) {
        $stmt = $conn->prepare("INSERT INTO suppliers (name, type, email, phone, address, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $type, $email, $phone, $address, $status);
    } elseif ($_POST['action'] == 'edit_supplier' && $supplier_id > 0) {
        $stmt = $conn->prepare("UPDATE suppliers SET name=?, type=?, email=?, phone=?, address=?, status=? WHERE id=?");
        $stmt->bind_param("ssssssi", $name, $type, $email, $phone, $address, $status, $supplier_id);
    } elseif ($_POST['action'] == 'delete_supplier') {
        $supplier_id = $_POST['supplierID'];
        $stmt = $conn->prepare("DELETE FROM suppliers WHERE id = ?");
        $stmt->bind_param("i", $supplier_id);
    }
    $stmt->execute();
    $stmt->close();
}

// Handle export functionality for CSV, TXT, PDF
if (isset($_POST['export'])) {
    $format = $_POST['format'];
    $columns = isset($_POST['columns']) ? $_POST['columns'] : [];

    if (empty($columns)) {
        die("No columns selected for export.");
    }

    $selectedColumns = implode(',', $columns);
    $filename = "suppliers_" . date('Ymd') . ".{$format}";

    // Fetch selected columns for export
    $exportQuery = "SELECT $selectedColumns FROM suppliers";
    $exportResult = $conn->query($exportQuery);

    // Prevent any output before handling the export
    ob_clean(); // Clean any previous output to avoid issues with PDF download

    if ($format == 'csv') {
        header('Content-Type: text/csv');
        header("Content-Disposition: attachment; filename=$filename");
        $output = fopen('php://output', 'w');
        fputcsv($output, $columns); // Write the headers
        while ($row = $exportResult->fetch_assoc()) {
            fputcsv($output, array_intersect_key($row, array_flip($columns)));
        }
        fclose($output);
        exit;

    } elseif ($format == 'txt') {
        header('Content-Type: text/plain');
        header("Content-Disposition: attachment; filename=$filename");
        $output = fopen('php://output', 'w');
        fwrite($output, implode("\t", $columns) . "\n");
        while ($row = $exportResult->fetch_assoc()) {
            fwrite($output, implode("\t", array_intersect_key($row, array_flip($columns))) . "\n");
        }
        fclose($output);
        exit;
    } elseif ($format == 'pdf') {
        require('fpdf/fpdf.php');
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Supplier List', 0, 1, 'C');
        $pdf->Ln(10);
        // Header row
        foreach ($columns as $column) {
            $pdf->Cell(30, 10, ucfirst(str_replace('_', ' ', $column)), 1);
        }
        $pdf->Ln();
        // Table data
        while ($row = $exportResult->fetch_assoc()) {
            foreach (array_intersect_key($row, array_flip($columns)) as $data) {
                $pdf->Cell(30, 10, $data, 1);
            }
            $pdf->Ln();
        }
        $pdf->Output('D', $filename); // D for download
        exit;
    }
}

// Pagination setup
$limit = 10; // Suppliers per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch suppliers with pagination, sorting by ID in descending order (most recent at the top)
$suppliers = [];
$supplierQuery = $conn->query("SELECT * FROM suppliers ORDER BY id DESC LIMIT $limit OFFSET $offset");
if ($supplierQuery->num_rows > 0) {
    while ($row = $supplierQuery->fetch_assoc()) {
        $suppliers[] = $row;
    }
}

// Total number of suppliers
$totalSuppliersResult = $conn->query("SELECT COUNT(*) as total FROM suppliers");
$totalSuppliers = $totalSuppliersResult->fetch_assoc()['total'];
$totalPages = ceil($totalSuppliers / $limit);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color:white;
            color: black;
            border-radius: 10px 10px 0 0;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .table-responsive {
            margin-top: 20px;
        }
        th {
            background-color: #00408e;
            color: white;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
        }

    </style>
</head>
<body>

    <div class="container">
        <div class="card">
                    <!-- Back to Home Button -->
                    <div class="mb-3">
    <a href="Inventory.php" class="btn mb-2" style="background-color: #00408e; color: #fff;">Back to Home</a>
</div>

            <div class="card-header">
                <h3>Supplier Management</h3>
            </div>
            <div class="card-body">
                <form id="supplierForm" method="POST" action="supplier_management.php">
                    <input type="hidden" name="supplierID" id="supplierID">
                    <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="supplierName">Supplier Name</label>
                            <input type="text" class="form-control" id="supplierName" name="supplierName" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="supplierType">Supplier Type</label>
                            <select class="form-control" id="supplierType" name="supplierType" required>
                                <option value="Manufacturer">Manufacturer</option>
                                <option value="Distributor">Distributor</option>
                                <option value="Retailer">Retailer</option>
                                <option value="Wholesaler">Wholesaler</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="contactEmail">Contact Email</label>
                            <input type="email" class="form-control" id="contactEmail" name="contactEmail" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="contactPhone">Contact Phone</label>
                            <input type="text" class="form-control" id="contactPhone" name="contactPhone" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="supplierStatus">Supplier Status</label>
                            <select class="form-control" id="supplierStatus" name="supplierStatus" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                    </div>
                    <button type="submit" name="action" value="add_supplier" id="submitBtn" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <form id="searchForm">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search suppliers..." id="search-input" onkeyup="searchSuppliers()">
                    <div class="input-group-append">
                        <button class="btn btn-secondary" type="button" id="clear-search-btn" onclick="clearSearch()" style="display:none;">Clear Search</button>
                    </div>
                </div>
            </form>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Supplier ID</th>
                        <th>Supplier Name</th>
                        <th>Supplier Type</th>
                        <th>Contact Email</th>
                        <th>Contact Phone</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="supplierTable">
                    <?php foreach ($suppliers as $supplier): ?>
                    <tr>
                        <td><?php echo $supplier['id']; ?></td>
                        <td><?php echo $supplier['name']; ?></td>
                        <td><?php echo $supplier['type']; ?></td>
                        <td><?php echo $supplier['email']; ?></td>
                        <td><?php echo $supplier['phone']; ?></td>
                        <td><?php echo $supplier['address']; ?></td>
                        <td><?php echo $supplier['status']; ?></td>
                        <td class="action-buttons">
                            <button class="btn btn-primary" onclick="editSupplier(<?php echo $supplier['id']; ?>, '<?php echo $supplier['name']; ?>', '<?php echo $supplier['type']; ?>', '<?php echo $supplier['email']; ?>', '<?php echo $supplier['phone']; ?>', '<?php echo $supplier['address']; ?>', '<?php echo $supplier['status']; ?>')">Edit</button>
                            <form method="POST" action="supplier_management.php" style="display:inline;">
                                <input type="hidden" name="supplierID" value="<?php echo $supplier['id']; ?>">
                                <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                                <button type="submit" name="action" value="delete_supplier" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination links -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>

        <!-- Export functionality -->
        <form method="POST" action="supplier_management.php" class="mt-4">
            <div class="form-group">
                <label for="format">Select Export Format</label>
                <select id="format" name="format" class="form-control" required>
                    <option value="csv">CSV</option>
                    <option value="txt">Text</option>
                    <option value="pdf">PDF</option>
                </select>
            </div>

            <div class="form-group">
                <label>Select Columns to Export</label>
                <select class="form-control" name="columns[]" multiple required>
                    <option value="id" selected>Supplier ID</option>
                    <option value="name" selected>Supplier Name</option>
                    <option value="type" selected>Supplier Type</option>
                    <option value="email" selected>Contact Email</option>
                    <option value="phone" selected>Contact Phone</option>
                    <option value="address" selected>Address</option>
                    <option value="status" selected>Status</option>
                </select>
            </div>

            <button type="submit" name="export" class="btn btn-success">Export Data</button>
        </form>
    </div>
<br>
<br>

    <script>
    function editSupplier(id, name, type, email, phone, address, status) {
        // Reset the form
        document.getElementById('supplierForm').reset();

        // Populate the form with the selected supplier data
        document.getElementById('supplierID').value = id;
        document.getElementById('supplierName').value = name;
        document.getElementById('supplierType').value = type;
        document.getElementById('contactEmail').value = email;
        document.getElementById('contactPhone').value = phone;
        document.getElementById('address').value = address;
        document.getElementById('supplierStatus').value = status;

        // Set the form action to edit_supplier and update button text
        document.getElementById('submitBtn').name = 'action';
        document.getElementById('submitBtn').value = 'edit_supplier';
        document.getElementById('submitBtn').textContent = 'Update Supplier';

        // Scroll to the form
        document.getElementById('supplierForm').scrollIntoView();
    }

    function searchSuppliers() {
        const input = document.getElementById('search-input').value.toLowerCase();
        const rows = document.querySelectorAll('#supplierTable tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const matches = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(input));
            row.style.display = matches ? '' : 'none';
        });

        // Show or hide the clear search button
        document.getElementById('clear-search-btn').style.display = input ? 'block' : 'none';
    }

    function clearSearch() {
        document.getElementById('search-input').value = '';
        searchSuppliers();
    }
    </script>

</body>
</html>
