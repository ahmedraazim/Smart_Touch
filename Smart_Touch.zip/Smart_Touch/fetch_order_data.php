<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_touch";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the order IDs from the request
$data = json_decode(file_get_contents('php://input'), true);
$orderIds = $data['orderIds'] ?? [];

// Prepare an array to hold the order data
$orders = [];

foreach ($orderIds as $orderId) {
    $orderDetailsQuery = $conn->query("SELECT * FROM purchase_orders WHERE order_number = '$orderId'");
    if ($orderDetailsQuery->num_rows > 0) {
        $order = $orderDetailsQuery->fetch_assoc();

        // Fetch received items
        $receivedItemsQuery = $conn->query("SELECT * FROM stock WHERE order_number = '$orderId'");
        $order['received_items'] = $receivedItemsQuery->fetch_all(MYSQLI_ASSOC);

        // Fetch returned items
        $returnedItemsQuery = $conn->query("SELECT * FROM supplier_return WHERE order_number = '$orderId'");
        $order['returned_items'] = $returnedItemsQuery->fetch_all(MYSQLI_ASSOC);

        $orders[] = $order;
    }
}

// Return the order data as JSON
echo json_encode($orders);
